--[[
    WhateverRoyale - SessionManager.lua
    Session lifecycle and round management

    Handles:
    - Creating and closing sessions
    - Round state management (signup, rolling, completed)
    - Sign-up processing
    - Roll processing and validation
    - Winner/loser calculation
    - Statistics updates
]]

local _, addon = ...

-- ============================================================================
-- Session Lifecycle
-- ============================================================================

-- Create a new game session
function addon:CreateNewSession(gameType, rollAmountOverride)
    -- Ensure database is initialized
    if not WhateverRoyaleDB then
        self:Error("Database not initialized. Please /reload and try again.")
        return nil
    end

    -- Ensure sessions table exists
    if not WhateverRoyaleDB.sessions then
        WhateverRoyaleDB.sessions = {}
    end

    -- Ensure settings exist
    if not WhateverRoyaleDB.settings then
        self:Error("Settings not initialized. Please /reload and try again.")
        return nil
    end

    local sessionId = self:GenerateSessionId()
    if not sessionId then
        self:Error("Failed to generate session ID")
        return nil
    end

    local currentChar = self:GetCurrentCharacterId()
    local channel = WhateverRoyaleDB.settings.defaultChannel

    local session = {
        sessionId = sessionId,
        gameType = gameType,
        startTime = time(),
        endTime = nil,
        status = "active",
        channel = channel,
        rollAmount = rollAmountOverride,  -- nil means: use DB default per round
        hostCharacter = currentChar,
        participants = {},
        rounds = {},
        sessionStats = {
            totalRounds = 0,
            totalPayouts = 0,
            leaderboard = {},
        },
    }

    WhateverRoyaleDB.sessions[sessionId] = session

    -- Start chat monitoring
    self:StartChannelMonitor(channel, sessionId)

    -- Create Session Frame UI (will be implemented in Phase 4)
    if self.CreateSessionFrame then
        self:CreateSessionFrame(sessionId)
    end

    self:Success(string.format("Session %s created!", sessionId))

    return sessionId
end

-- Close a session
function addon:CloseSession(sessionId, force)
    local session = self:GetSession(sessionId)
    if not session then
        self:Error("Session not found: " .. tostring(sessionId))
        return
    end

    -- Check for confirmation if there's an active round
    if not force and WhateverRoyaleDB.settings.confirmSessionClose then
        local currentRound = session.rounds[#session.rounds]
        if currentRound and currentRound.status ~= "completed" then
            -- Show confirmation dialog (implement later with UI)
            self:Warning("Session has active round. Use /wr closesession force to close anyway.")
            return
        end
    end

    session.status = "completed"
    session.endTime = time()

    -- Update session completion statistics
    self:UpdateSessionCompletionStats(sessionId)

    -- Send SESSION_END to clients so they know to reset
    self:SendAddonMessage("SESSION_END", sessionId, session.channel)

    -- Auto-share completed session with group peers
    if self.AutoShareSession then self:AutoShareSession(sessionId) end

    -- Stop chat monitoring
    self:StopChannelMonitor()

    -- Close Session Frame UI
    if addon.sessionFrames and addon.sessionFrames[sessionId] then
        addon.sessionFrames[sessionId]:Hide()
    end

    self:Success("Session closed")
end

-- ============================================================================
-- Round Management
-- ============================================================================

-- Start a new sign-up round
function addon:StartSignUp(sessionId)
    local session = self:GetSession(sessionId)
    if not session then
        self:Error("Session not found")
        return
    end

    local roundNumber = #session.rounds + 1

    local round = {
        roundNumber = roundNumber,
        startTime = time(),
        endTime = nil,
        status = "signup",
        signedUp = {},
        rolls = {},
        results = nil,

        -- Death-Roll specific fields
        deathRollState = session.gameType == "deathRoll" and {
            phase = "signup",  -- signup → starter_roll → death_rolling → completed
            player1 = nil,     -- First player to sign up
            player2 = nil,     -- Second player to sign up
            starter = nil,     -- Who goes first (determined by /roll 100)
            currentPlayer = nil,  -- Whose turn to roll
            expectedMax = nil,    -- What the next roll max should be
            rollHistory = {},     -- {player, roll, timestamp}
        } or nil,
    }

    session.rounds[roundNumber] = round

    -- Announce in chat (game-specific message)
    if session.gameType == "deathRoll" then
        local startAmount = WhateverRoyaleDB.gameSettings.deathRoll.startAmount
        local startAmountText = tostring(startAmount):reverse():gsub("(%d%d%d)", "%1."):reverse():gsub("^%.", "")
        self:AnnounceToChannel(session.channel,
            string.format("Death-Roll - #%d - %s g - 1 in den chjat! (2 Spieler)",
                roundNumber, startAmountText))
    else
        -- Simple Dice
        local rollAmount = session.rollAmount or WhateverRoyaleDB.gameSettings[session.gameType].rollAmount
        -- Format number with dots as thousand separators: 25000 -> "25.000"
        local rollAmountText = tostring(rollAmount):reverse():gsub("(%d%d%d)", "%1."):reverse():gsub("^%.", "")
        self:AnnounceToChannel(session.channel,
            string.format("Wer nicht mitspielt KANN NUR VERLIEREN! #%d - %s g - 1 in den chjat!",
                roundNumber, rollAmountText))
    end

    -- Update Session Frame UI
    if self.UpdateSessionFrame then
        self:UpdateSessionFrame(sessionId)
    end

    self:Info("Sign-up started for Round " .. roundNumber)
end

-- Last call announcement with countdown
function addon:LastCall(sessionId)
    local session = self:GetSession(sessionId)
    if not session then return end

    local currentRound = session.rounds[#session.rounds]
    if not currentRound then
        self:Warning("No active round")
        return
    end

    if currentRound.status == "signup" then
        -- Announce last call for sign-ups
        self:AnnounceToChannel(session.channel, "Last Call! 3 Sekunden...")

        -- Start 3-second countdown
        C_Timer.After(3, function()
            -- Auto-start rolling after countdown
            self:StartRolling(sessionId)
        end)
    elseif currentRound.status == "rolling" then
        -- Announce missing players
        local missing = self:GetMissingPlayers(sessionId, currentRound.roundNumber)
        if #missing > 0 then
            self:AnnounceToChannel(session.channel,
                "ÖY DU: " .. table.concat(missing, ", "))
        else
            self:Info("All players have rolled!")
        end
    end
end

-- Get list of players who haven't rolled yet
function addon:GetMissingPlayers(sessionId, roundNumber)
    local session = self:GetSession(sessionId)
    local round = session.rounds[roundNumber]
    local missing = {}

    for playerId in pairs(round.signedUp) do
        if not round.rolls[playerId] then
            local name = strsplit("-", playerId) -- Just show name without realm
            table.insert(missing, name)
        end
    end

    return missing
end

-- Start the rolling phase
function addon:StartRolling(sessionId)
    local session = self:GetSession(sessionId)
    if not session then return end

    local currentRound = session.rounds[#session.rounds]
    if not currentRound then
        self:Warning("No active round")
        return
    end

    if currentRound.status ~= "signup" then
        self:Warning("Round is not in signup phase")
        return
    end

    -- Check if anyone signed up
    local signUpCount = 0
    for _ in pairs(currentRound.signedUp) do
        signUpCount = signUpCount + 1
    end

    if signUpCount < WhateverRoyaleDB.gameSettings[session.gameType].minPlayers then
        self:Warning(string.format("Need at least %d players to start",
            WhateverRoyaleDB.gameSettings[session.gameType].minPlayers))
        return
    end

    -- Build participant list and send to clients before ROLL_NOW
    -- Format: "sessionId:player1|player2|..."
    local participantList = {}
    for characterId, _ in pairs(currentRound.signedUp) do
        table.insert(participantList, characterId)
    end
    local participantsData = sessionId .. ":" .. table.concat(participantList, "|")
    self:SendAddonMessage("PARTICIPANTS", participantsData, session.channel)

    if session.gameType == "deathRoll" then
        -- Death-Roll: First /roll 100 to determine starter
        currentRound.deathRollState.phase = "starter_roll"
        currentRound.deathRollState.expectedMax = 100
        currentRound.status = "rolling"

        self:AnnounceToChannel(session.channel,
            string.format("%s vs %s - Wer fängt an? /roll 100",
                currentRound.deathRollState.player1, currentRound.deathRollState.player2))

        -- Send ROLL_NOW to clients for DeathRoll (starter phase)
        -- Format: sessionId:roundNumber:rollAmount:gameType:wagerAmount:channel
        local wagerAmount = WhateverRoyaleDB.gameSettings.deathRoll.startAmount
        local rollData = sessionId .. ":" .. currentRound.roundNumber .. ":100:deathRoll:" .. wagerAmount .. ":" .. session.channel
        self:SendAddonMessage("ROLL_NOW", rollData, session.channel)
    else
        -- Simple Dice logic
        currentRound.status = "rolling"

        local rollAmount = session.rollAmount or WhateverRoyaleDB.gameSettings[session.gameType].rollAmount

        self:AnnounceToChannel(session.channel,
            string.format("ALGEALGEALGEALGE /roll %d", rollAmount))

        -- Send ROLL_NOW to clients
        -- Format: sessionId:roundNumber:rollAmount:gameType::channel (empty wagerAmount for simpleDice)
        local rollData = sessionId .. ":" .. currentRound.roundNumber .. ":" .. rollAmount .. ":simpleDice::" .. session.channel
        self:SendAddonMessage("ROLL_NOW", rollData, session.channel)
    end

    -- Update Session Frame UI
    if self.UpdateSessionFrame then
        self:UpdateSessionFrame(sessionId)
    end

    self:Info("Rolling started")
end

-- ============================================================================
-- Sign-Up Processing
-- ============================================================================

function addon:ProcessSignUp(playerName, isSigningUp)
    local sessionId = self.chatMonitor.activeSessionId
    if not sessionId then return end

    local session = self:GetSession(sessionId)
    if not session then return end

    local currentRound = session.rounds[#session.rounds]
    if not currentRound then return end

    if currentRound.status ~= "signup" then
        return -- Ignore sign-ups outside signup phase
    end

    -- playerName is already "Name-Realm" format from normalization
    local characterId = playerName

    if isSigningUp then
        -- Death-Roll specific: Only accept first 2 players
        if session.gameType == "deathRoll" then
            local signedUpCount = 0
            for _ in pairs(currentRound.signedUp) do
                signedUpCount = signedUpCount + 1
            end

            if signedUpCount >= 2 then
                self:Debug("Death-Roll already has 2 players, ignoring sign-up from " .. characterId)
                return
            end

            -- Track player order
            if signedUpCount == 0 then
                currentRound.deathRollState.player1 = characterId
            elseif signedUpCount == 1 then
                currentRound.deathRollState.player2 = characterId
            end
        end

        currentRound.signedUp[characterId] = true
        session.participants[characterId] = true
        self:Debug(characterId .. " signed up")
    else
        currentRound.signedUp[characterId] = nil
        self:Debug(characterId .. " cancelled sign-up")
    end

    -- Update Session Frame UI
    if self.UpdateSessionFrame then
        self:UpdateSessionFrame(sessionId)
    end
end

-- ============================================================================
-- Roll Processing
-- ============================================================================

function addon:ProcessRoll(rollData)
    local sessionId = self.chatMonitor.activeSessionId
    if not sessionId then return end

    local session = self:GetSession(sessionId)
    if not session then return end

    local currentRound = session.rounds[#session.rounds]
    if not currentRound then return end

    if currentRound.status ~= "rolling" then
        return -- Ignore rolls outside rolling phase
    end

    -- rollData.player is already "Name-Realm" format from normalization
    local characterId = rollData.player

    -- Only accept rolls from signed-up players
    if not currentRound.signedUp[characterId] then
        self:Debug(characterId .. " rolled but wasn't signed up - ignoring")
        return
    end

    -- DEATH-ROLL SPECIFIC LOGIC
    if session.gameType == "deathRoll" then
        local drState = currentRound.deathRollState

        -- Phase 1: Starter determination (/roll 100)
        if drState.phase == "starter_roll" then
            -- Accept one roll from each player (not first-roll-only)
            if not currentRound.rolls[characterId] then
                currentRound.rolls[characterId] = {
                    roll = rollData.result,
                    maxRoll = rollData.max,
                    timestamp = time(),
                }

                -- Add to history
                table.insert(drState.rollHistory, {
                    player = characterId,
                    roll = rollData.result,
                    max = rollData.max,
                    timestamp = time(),
                })

                self:UpdateSessionFrame(sessionId)

                -- Check if both players rolled
                local rollCount = 0
                for _ in pairs(currentRound.rolls) do rollCount = rollCount + 1 end

                if rollCount == 2 then
                    -- Determine starter (highest roll)
                    local p1Roll = currentRound.rolls[drState.player1].roll
                    local p2Roll = currentRound.rolls[drState.player2].roll

                    if p1Roll > p2Roll then
                        drState.starter = drState.player1
                        drState.currentPlayer = drState.player1
                    elseif p2Roll > p1Roll then
                        drState.starter = drState.player2
                        drState.currentPlayer = drState.player2
                    else
                        -- Tie - re-roll
                        currentRound.rolls = {}
                        self:AnnounceToChannel(session.channel, "Unentschieden - /roll 100")
                        return
                    end

                    -- Start death-rolling phase
                    drState.phase = "death_rolling"
                    drState.expectedMax = WhateverRoyaleDB.gameSettings.deathRoll.startAmount
                    currentRound.rolls = {}  -- Clear starter rolls

                    self:AnnounceToChannel(session.channel,
                        string.format("%s fängt an! /roll %d", drState.currentPlayer, drState.expectedMax))

                    -- Send DR_TURN to clients: sessionId:currentPlayer:expectedMax
                    local turnData = sessionId .. ":" .. drState.currentPlayer .. ":" .. drState.expectedMax
                    self:SendAddonMessage("DR_TURN", turnData, session.channel)

                    self:UpdateSessionFrame(sessionId)
                end
            end
            return
        end

        -- Phase 2: Death-rolling (decreasing rolls until someone hits 1)
        if drState.phase == "death_rolling" then
            -- Only accept roll from current player
            if characterId ~= drState.currentPlayer then
                self:Debug("Not this player's turn")
                return
            end

            -- Validate roll max matches expected
            if rollData.max ~= drState.expectedMax then
                self:Debug(string.format("Invalid roll max %d, expected %d", rollData.max, drState.expectedMax))
                return
            end

            -- Record roll
            table.insert(drState.rollHistory, {
                player = characterId,
                roll = rollData.result,
                max = rollData.max,
                timestamp = time(),
            })

            self:UpdateSessionFrame(sessionId)

            -- Check if player rolled a 1 (loses)
            if rollData.result == 1 then
                self:CompleteRound(sessionId, currentRound.roundNumber)
                return
            end

            -- Switch to other player, set new expected max
            drState.currentPlayer = (drState.currentPlayer == drState.player1)
                and drState.player2 or drState.player1
            drState.expectedMax = rollData.result

            self:AnnounceToChannel(session.channel,
                string.format("%s - /roll %d", drState.currentPlayer, drState.expectedMax))

            -- Send DR_TURN to clients: sessionId:currentPlayer:expectedMax
            local turnData = sessionId .. ":" .. drState.currentPlayer .. ":" .. drState.expectedMax
            self:SendAddonMessage("DR_TURN", turnData, session.channel)

            self:UpdateSessionFrame(sessionId)
        end

        return
    end

    -- SIMPLE DICE LOGIC (existing code)
    -- Only accept first roll (ignore subsequent)
    if currentRound.rolls[characterId] then
        self:Debug(characterId .. " rolled again - ignoring")
        return
    end

    -- Record the roll
    currentRound.rolls[characterId] = {
        roll = rollData.result,
        maxRoll = rollData.max,
        timestamp = time(),
    }

    self:Debug(string.format("%s rolled %d", characterId, rollData.result))

    -- Update Session Frame UI
    if self.UpdateSessionFrame then
        self:UpdateSessionFrame(sessionId)
    end

    -- Check if all players have rolled
    local allRolled = true
    for playerId in pairs(currentRound.signedUp) do
        if not currentRound.rolls[playerId] then
            allRolled = false
            break
        end
    end

    if allRolled then
        self:CompleteRound(sessionId, currentRound.roundNumber)
    end
end

-- ============================================================================
-- Round Completion
-- ============================================================================

function addon:CompleteRound(sessionId, roundNumber)
    local session = self:GetSession(sessionId)
    local round = session.rounds[roundNumber]

    -- Calculate results
    local results = self:CalculateRoundResults(sessionId, roundNumber)
    round.results = results
    round.status = "completed"
    round.endTime = time()

    -- Get short names for announcement
    local winnerName = strsplit("-", results.winner)
    local loserName = strsplit("-", results.loser)

    -- Announce winner
    if WhateverRoyaleDB.settings.autoAnnounceResults then
        self:AnnounceToChannel(session.channel,
            string.format("%s investiert %dg in %s",
                loserName, results.payoutAmount, winnerName))
    end

    -- Update statistics
    self:UpdateRoundStatistics(sessionId, roundNumber)

    -- Send ROUND_END to clients
    local resultData = string.format("%s:%d:%s:%s:%d",
        sessionId, roundNumber, results.winner, results.loser, results.payoutAmount)
    self:SendAddonMessage("ROUND_END", resultData, session.channel)

    -- Update Session Frame UI
    if self.UpdateSessionFrame then
        self:UpdateSessionFrame(sessionId)
    end

    self:Success(string.format("Round %d complete! %s wins %dg",
        roundNumber, winnerName, results.payoutAmount))
end

function addon:CalculateRoundResults(sessionId, roundNumber)
    local session = self:GetSession(sessionId)
    local round = session.rounds[roundNumber]

    if session.gameType == "deathRoll" then
        -- Death-Roll: Find who rolled 1 (loser)
        local loser = nil
        local winner = nil

        for _, rollEntry in ipairs(round.deathRollState.rollHistory) do
            if rollEntry.roll == 1 then
                loser = rollEntry.player
                break
            end
        end

        -- Winner is the other player
        winner = (loser == round.deathRollState.player1)
            and round.deathRollState.player2
            or round.deathRollState.player1

        local payoutAmount = WhateverRoyaleDB.gameSettings.deathRoll.startAmount

        return {
            winner = winner,
            loser = loser,
            payoutAmount = payoutAmount,
            highestRoll = nil,  -- Not applicable
            lowestRoll = 1,     -- Loser always rolls 1
        }
    end

    -- Simple Dice logic (existing)
    local highestRoll = 0
    local lowestRoll = 999999
    local winner = nil
    local loser = nil

    for playerId, rollData in pairs(round.rolls) do
        if rollData.roll > highestRoll then
            highestRoll = rollData.roll
            winner = playerId
        end
        if rollData.roll < lowestRoll then
            lowestRoll = rollData.roll
            loser = playerId
        end
    end

    local payoutAmount = highestRoll - lowestRoll

    return {
        winner = winner,
        loser = loser,
        payoutAmount = payoutAmount,
        highestRoll = highestRoll,
        lowestRoll = lowestRoll,
    }
end

-- ============================================================================
-- Statistics Updates
-- ============================================================================

function addon:UpdateRoundStatistics(sessionId, roundNumber)
    local session = self:GetSession(sessionId)
    local round = session.rounds[roundNumber]
    local results = round.results

    -- Update session leaderboard
    session.sessionStats.totalRounds = session.sessionStats.totalRounds + 1
    session.sessionStats.totalPayouts = session.sessionStats.totalPayouts + results.payoutAmount

    session.sessionStats.leaderboard[results.winner] =
        (session.sessionStats.leaderboard[results.winner] or 0) + results.payoutAmount

    session.sessionStats.leaderboard[results.loser] =
        (session.sessionStats.leaderboard[results.loser] or 0) - results.payoutAmount

    -- Update character statistics
    self:UpdateCharacterStatsFromRound(session, round)

    -- Refresh Statistics tab if it exists
    if self.tabs and self.tabs.statistics then
        self:RefreshLeaderboard(self.tabs.statistics)
    end
end

function addon:UpdateCharacterStatsFromRound(session, round)
    if round.status ~= "completed" or not round.results then return end

    local results = round.results
    local gameType = session.gameType

    -- Update winner stats
    local winnerChar = self:GetOrCreateCharacter(results.winner)
    self:IncrementCharacterStats(winnerChar, gameType, session.sessionId, {
        roundsPlayed = 1,
        roundsWon = 1,
        goldWon = results.payoutAmount,
    })

    -- Update loser stats
    local loserChar = self:GetOrCreateCharacter(results.loser)
    self:IncrementCharacterStats(loserChar, gameType, session.sessionId, {
        roundsPlayed = 1,
        roundsLost = 1,
        goldLost = results.payoutAmount,
    })
end

function addon:IncrementCharacterStats(character, gameType, sessionId, increments)
    -- Ensure game stats exist
    if not character.stats.byGame[gameType] then
        character.stats.byGame[gameType] = self:CreateEmptyStats()
    end

    -- Update overall stats
    if increments.roundsPlayed then
        character.stats.overall.totalRounds =
            character.stats.overall.totalRounds + increments.roundsPlayed
    end
    if increments.roundsWon then
        character.stats.overall.roundsWon =
            character.stats.overall.roundsWon + increments.roundsWon
    end
    if increments.roundsLost then
        character.stats.overall.roundsLost =
            character.stats.overall.roundsLost + increments.roundsLost
    end
    if increments.goldWon then
        character.stats.overall.totalGoldWon =
            character.stats.overall.totalGoldWon + increments.goldWon
        character.stats.overall.netBalance =
            character.stats.overall.netBalance + increments.goldWon

        if increments.goldWon > character.stats.overall.biggestWin then
            character.stats.overall.biggestWin = increments.goldWon
        end
    end
    if increments.goldLost then
        character.stats.overall.totalGoldLost =
            character.stats.overall.totalGoldLost + increments.goldLost
        character.stats.overall.netBalance =
            character.stats.overall.netBalance - increments.goldLost

        if increments.goldLost > character.stats.overall.biggestLoss then
            character.stats.overall.biggestLoss = increments.goldLost
        end
    end

    -- Recalculate win rate
    if character.stats.overall.totalRounds > 0 then
        character.stats.overall.winRate =
            character.stats.overall.roundsWon / character.stats.overall.totalRounds
    end

    -- Update game-specific stats (same logic)
    local gameStats = character.stats.byGame[gameType]
    if increments.roundsPlayed then
        gameStats.totalRounds = gameStats.totalRounds + increments.roundsPlayed
    end
    if increments.roundsWon then
        gameStats.roundsWon = gameStats.roundsWon + increments.roundsWon
    end
    if increments.roundsLost then
        gameStats.roundsLost = gameStats.roundsLost + increments.roundsLost
    end
    if increments.goldWon then
        gameStats.totalGoldWon = gameStats.totalGoldWon + increments.goldWon
        gameStats.netBalance = gameStats.netBalance + increments.goldWon
        if increments.goldWon > gameStats.biggestWin then
            gameStats.biggestWin = increments.goldWon
        end
    end
    if increments.goldLost then
        gameStats.totalGoldLost = gameStats.totalGoldLost + increments.goldLost
        gameStats.netBalance = gameStats.netBalance - increments.goldLost
        if increments.goldLost > gameStats.biggestLoss then
            gameStats.biggestLoss = increments.goldLost
        end
    end

    if gameStats.totalRounds > 0 then
        gameStats.winRate = gameStats.roundsWon / gameStats.totalRounds
    end

    -- Update session history
    if not character.stats.sessionHistory[sessionId] then
        character.stats.sessionHistory[sessionId] = {
            sessionId = sessionId,
            gameType = gameType,
            roundsPlayed = 0,
            roundsWon = 0,
            sessionBalance = 0,
            startTime = WhateverRoyaleDB.sessions[sessionId].startTime,
            endTime = nil,
        }
    end

    local sessionHistory = character.stats.sessionHistory[sessionId]
    if increments.roundsPlayed then
        sessionHistory.roundsPlayed = sessionHistory.roundsPlayed + increments.roundsPlayed
    end
    if increments.roundsWon then
        sessionHistory.roundsWon = sessionHistory.roundsWon + increments.roundsWon
    end
    if increments.goldWon then
        sessionHistory.sessionBalance = sessionHistory.sessionBalance + increments.goldWon
    end
    if increments.goldLost then
        sessionHistory.sessionBalance = sessionHistory.sessionBalance - increments.goldLost
    end

    -- Update best/worst session statistics
    local sessionBalance = character.stats.sessionHistory[sessionId].sessionBalance

    -- Update best/worst session (overall)
    if sessionBalance > character.stats.overall.bestSession then
        character.stats.overall.bestSession = sessionBalance
    end
    if sessionBalance < character.stats.overall.worstSession then
        character.stats.overall.worstSession = sessionBalance
    end

    -- Update best/worst session (by game type)
    if sessionBalance > character.stats.byGame[gameType].bestSession then
        character.stats.byGame[gameType].bestSession = sessionBalance
    end
    if sessionBalance < character.stats.byGame[gameType].worstSession then
        character.stats.byGame[gameType].worstSession = sessionBalance
    end
end

function addon:UpdateSessionCompletionStats(sessionId)
    local session = self:GetSession(sessionId)
    if not session then return end

    -- Track unique participants across all rounds
    local participants = {}
    for _, round in ipairs(session.rounds) do
        for characterId, _ in pairs(round.signedUp) do
            participants[characterId] = true
        end
    end

    -- Increment totalSessions for all participants
    for characterId, _ in pairs(participants) do
        local character = self:GetOrCreateCharacter(characterId)
        character.stats.overall.totalSessions = character.stats.overall.totalSessions + 1

        if character.stats.byGame[session.gameType] then
            character.stats.byGame[session.gameType].totalSessions =
                character.stats.byGame[session.gameType].totalSessions + 1
        end
    end
end

-- Post session stats (top/flop N) to chat
function addon:PostSessionStats(sessionId, n, channel)
    n = math.max(1, math.min(n or 5, 10))
    channel = channel or "RAID"

    local session = self:GetSession(sessionId)
    if not session then
        self:Error("Session nicht gefunden.")
        return
    end

    if session.sessionStats.totalRounds == 0 then
        self:Warning("Noch keine abgeschlossenen Runden in dieser Session.")
        return
    end

    -- Build sorted list from accumulated session leaderboard
    local entries = {}
    for charId, balance in pairs(session.sessionStats.leaderboard) do
        local name = strsplit("-", charId)
        table.insert(entries, {name = name, balance = balance})
    end
    table.sort(entries, function(a, b) return a.balance > b.balance end)

    local rounds = session.sessionStats.totalRounds
    local totalText = tostring(session.sessionStats.totalPayouts):reverse():gsub("(%d%d%d)", "%1."):reverse():gsub("^%.", "")

    -- Header
    self:AnnounceToChannel(channel, string.format(
        "[WR] Session — %d Runden | %sg Gesamteinsatz", rounds, totalText))

    -- Top N, one line per rank
    local topCount = math.min(n, #entries)
    self:AnnounceToChannel(channel, string.format("[WR] Top %d:", topCount))
    for i = 1, topCount do
        local e = entries[i]
        self:AnnounceToChannel(channel, string.format("%d. %s: %s", i, e.name, self:FormatBalance(e.balance)))
    end

    -- Flop N, worst-first, one line per rank
    self:AnnounceToChannel(channel, string.format("[WR] Flop %d:", topCount))
    for i = #entries, math.max(#entries - n + 1, 1), -1 do
        local e = entries[i]
        local rank = #entries - i + 1
        self:AnnounceToChannel(channel, string.format("%d. %s: %s", rank, e.name, self:FormatBalance(e.balance)))
    end
end
