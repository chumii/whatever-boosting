--[[
    WhateverRoyale - ChatMonitor.lua
    Chat monitoring and roll detection system

    Monitors chat channels for:
    - Player sign-ups ("1" to join, "0" to leave)
    - /roll commands with specific amounts
]]

local addonName, addon = ...

-- ============================================================================
-- Roll Detection Pattern (Localization-Safe)
-- ============================================================================

local rollPattern
do
    ---@diagnostic disable-next-line: undefined-global
    local formatString = RANDOM_ROLL_RESULT

    -- Debug: Show what WoW actually provides
    -- if formatString then
    --     print("[WhateverRoyale Debug] RANDOM_ROLL_RESULT = " .. tostring(formatString))
    -- end

    -- Use CrossGambling's proven pattern (English WoW clients)
    -- Format expected: "PlayerName rolls 12345 (1-25000)"
    -- Pattern breakdown:
    --   ^([^ ]+)          - Player name (non-space chars at line start)
    --   .+                - " rolls " or localized equivalent
    --   (%d+)             - Roll result (one or more digits)
    --   %((%d+)%-(%d+)%)  - Range: (min-max) with escaped parentheses
    --   %.?$              - Optional period at end of line
    rollPattern = "^([^ ]+) .+ (%d+) %((%d+)%-(%d+)%)%.?$"
end

-- Helper: Normalize player name to "Name-Realm" format
-- If the name already has a realm, keep it. Otherwise add host's realm (same-realm players).
local function normalizePlayerName(playerName)
    -- Check if realm is already included
    if string.find(playerName, "-") then
        -- Already has realm, return as-is
        return playerName
    end

    -- No realm in name - add host's realm (for same-realm players)
    local realm = GetRealmName()
    return playerName .. "-" .. realm
end

-- Parse roll message
local function parseRoll(message)
    local playerName, rollResult, rollMin, rollMax =
        string.match(message, rollPattern)

    if playerName then
        return {
            player = playerName,  -- Keep raw name, will resolve realm later
            result = tonumber(rollResult),
            min = tonumber(rollMin),
            max = tonumber(rollMax)
        }
    end
    return nil
end

-- Helper: Find full characterId from signed-up players by matching name
-- Roll messages don't include realm, so we need to match against sign-ups
local function findSignedUpPlayer(playerName, signedUpList)
    -- First try exact match (for same-realm players where name might include realm)
    if signedUpList[playerName] then
        return playerName
    end

    -- Try matching by name only (for cross-realm rolls)
    local nameOnly = strsplit("-", playerName)
    for characterId in pairs(signedUpList) do
        local signedUpName = strsplit("-", characterId)
        if signedUpName == nameOnly then
            return characterId
        end
    end

    return nil
end

-- ============================================================================
-- Channel Event Mapping
-- ============================================================================

addon.CHANNEL_EVENTS = {
    PARTY = {"CHAT_MSG_PARTY", "CHAT_MSG_PARTY_LEADER"},
    RAID = {"CHAT_MSG_RAID", "CHAT_MSG_RAID_LEADER"},
    INSTANCE = {"CHAT_MSG_INSTANCE_CHAT"},
    GUILD = {"CHAT_MSG_GUILD"}
}

-- ============================================================================
-- Monitoring State
-- ============================================================================

addon.chatMonitor = {
    enabled = false,
    activeChannel = nil,
    activeSessionId = nil,
}

-- ============================================================================
-- Chat Monitoring Functions
-- ============================================================================

-- Start monitoring a channel for a session
function addon:StartChannelMonitor(channelType, sessionId)
    if not self.CHANNEL_EVENTS[channelType] then
        self:Error("Invalid channel type: " .. tostring(channelType))
        return false
    end

    -- Enable monitoring
    self.chatMonitor.enabled = true
    self.chatMonitor.activeChannel = channelType
    self.chatMonitor.activeSessionId = sessionId

    -- Register channel events (including leader variants)
    local events = self.CHANNEL_EVENTS[channelType]
    for _, event in ipairs(events) do
        self.eventFrame:RegisterEvent(event)
    end

    self:Info(string.format("Now monitoring %s channel for session %s",
        channelType, sessionId))

    return true
end

-- Stop monitoring channels
function addon:StopChannelMonitor()
    self.chatMonitor.enabled = false

    if self.chatMonitor.activeChannel then
        local events = self.CHANNEL_EVENTS[self.chatMonitor.activeChannel]
        for _, event in ipairs(events) do
            self.eventFrame:UnregisterEvent(event)
        end

        self:Debug("Stopped monitoring " .. self.chatMonitor.activeChannel)
    end

    self.chatMonitor.activeChannel = nil
    self.chatMonitor.activeSessionId = nil
end

-- ============================================================================
-- Message Processing
-- ============================================================================

-- Process roll message from CHAT_MSG_SYSTEM
function addon:ProcessRollMessage(message)
    if not self.chatMonitor.enabled then return end
    if not self.chatMonitor.activeSessionId then return end

    local rollData = parseRoll(message)
    if not rollData then return end

    self:Debug(string.format("Detected roll: %s rolled %d (%d-%d)",
        rollData.player, rollData.result, rollData.min, rollData.max))

    -- Get active session
    local session = self:GetSession(self.chatMonitor.activeSessionId)
    if not session then
        self:Debug("No active session found")
        return
    end

    -- Check if roll matches target amount
    local targetAmount
    if session.gameType == "deathRoll" then
        local currentRound = session.rounds[#session.rounds]
        if currentRound.deathRollState then
            targetAmount = currentRound.deathRollState.expectedMax
        end
    else
        targetAmount = session.rollAmount or WhateverRoyaleDB.gameSettings[session.gameType].rollAmount
    end

    if not targetAmount or rollData.max ~= targetAmount then
        self:Debug(string.format("Roll ignored - max %d doesn't match target %d",
            rollData.max, targetAmount or 0))
        return
    end

    -- Resolve player name to full characterId from signed-up list
    -- Roll messages don't include realm, so we match by name against sign-ups
    local currentRound = session.rounds[#session.rounds]
    if currentRound then
        local resolvedPlayer = findSignedUpPlayer(rollData.player, currentRound.signedUp)
        if resolvedPlayer then
            rollData.player = resolvedPlayer
            self:Debug(string.format("Resolved player to: %s", resolvedPlayer))
        else
            -- Fallback: add host's realm for same-realm players
            rollData.player = normalizePlayerName(rollData.player)
            self:Debug(string.format("Player not in sign-ups, normalized to: %s", rollData.player))
        end
    end

    -- Process the roll (handled by SessionManager)
    self:ProcessRoll(rollData)
end

-- Process channel message for sign-ups
function addon:ProcessChannelMessage(text, playerName)
    if not self.chatMonitor.enabled then return end
    if not self.chatMonitor.activeSessionId then return end

    local trimmed = strtrim(text)

    -- Normalize player name before processing
    local normalizedName = normalizePlayerName(playerName)

    if trimmed == "1" or trimmed == "in" then
        self:Debug(normalizedName .. " typed '1' (sign up)")
        self:ProcessSignUp(normalizedName, true)
    elseif trimmed == "0" or trimmed == "-1" or trimmed == "out" then
        self:Debug(normalizedName .. " typed '0' (cancel)")
        self:ProcessSignUp(normalizedName, false)
    end
end

-- ============================================================================
-- Channel Announcement
-- ============================================================================

-- Announce message to the monitored channel
function addon:AnnounceToChannel(channelType, message)
    ---@diagnostic disable-next-line: deprecated
    local inInstance = IsInGroup(LE_PARTY_CATEGORY_INSTANCE)
    ---@diagnostic disable-next-line: deprecated
    local inRaid = IsInRaid()
    ---@diagnostic disable-next-line: deprecated
    local inParty = IsInGroup()
    ---@diagnostic disable-next-line: deprecated
    local inGuild = IsInGuild()

    self:Debug(string.format("AnnounceToChannel: %s | Message: '%s' | inParty=%s, inRaid=%s, inInstance=%s",
        channelType, message, tostring(inParty), tostring(inRaid), tostring(inInstance)))

    if channelType == "PARTY" then
        if inInstance then
            SendChatMessage(message, "INSTANCE_CHAT")
            self:Debug("Sent to INSTANCE_CHAT")
        elseif inRaid then
            SendChatMessage(message, "RAID")
            self:Debug("Sent to RAID")
        elseif inParty then
            SendChatMessage(message, "PARTY")
            self:Debug("Sent to PARTY")
        else
            self:Warning("Not in a party/raid - cannot announce")
        end
    elseif channelType == "RAID" then
        if inRaid then
            SendChatMessage(message, "RAID")
            self:Debug("Sent to RAID")
        else
            self:Warning("Not in a raid - cannot announce")
        end
    elseif channelType == "INSTANCE" then
        if inInstance then
            SendChatMessage(message, "INSTANCE_CHAT")
            self:Debug("Sent to INSTANCE_CHAT")
        else
            self:Warning("Not in an instance group - cannot announce")
        end
    elseif channelType == "GUILD" then
        if inGuild then
            SendChatMessage(message, "GUILD")
            self:Debug("Sent to GUILD")
        else
            self:Warning("Not in a guild - cannot announce")
        end
    end
end
