--[[
    WhateverRoyaleClient - DeathRoll.lua
    Death-Roll UI frame using PixelUI
]]
local addonName, addon = ...
local PixelUI = addon.PixelUI
local LCG = LibStub and LibStub("LibCustomGlow-1.0", true)

-- Layout constants
local FRAME_WIDTH = 250
local FRAME_PADDING = 10
local CONTENT_WIDTH = FRAME_WIDTH - (FRAME_PADDING * 2) - 2  -- 228px usable

-- Create the DeathRoll Frame
function addon:CreateDeathRollFrame()
    local frame = PixelUI.CreateMainFrame(
        UIParent,
        "WRCDeathRollFrame",
        "Death-Roll",
        FRAME_WIDTH,
        310
    )
    PixelUI.SetPoint(frame, "CENTER", 150, 0)  -- Offset from SimpleDice
    frame:SetTitleJustify("CENTER")

    -- Store frame reference in addon namespace
    addon.deathRollFrame = frame

    -- Button widths: two buttons + gap = content width
    local btnWidth = (CONTENT_WIDTH - 10) / 2  -- 109px each

    -- In Button
    local btnIn = PixelUI.CreateButton(frame.content, "In", "primary", btnWidth, 20)
    PixelUI.SetPoint(btnIn, "TOPLEFT", FRAME_PADDING, -10)
    btnIn:SetOnClick(function()
        SendChatMessage("in", addon.deathRollSession.channel or "PARTY")
    end)
    frame.btnIn = btnIn

    -- Out Button
    local btnOut = PixelUI.CreateButton(frame.content, "Out", "danger", btnWidth, 20)
    PixelUI.SetPoint(btnOut, "TOPLEFT", btnIn, "TOPRIGHT", 10, 0)
    btnOut:SetOnClick(function()
        SendChatMessage("out", addon.deathRollSession.channel or "PARTY")
    end)
    frame.btnOut = btnOut

    -- Roll Button (shows current max when it's your turn)
    local btnRoll = PixelUI.CreateButton(frame.content, "Roll", "accent", CONTENT_WIDTH, 25)
    PixelUI.SetPoint(btnRoll, "TOPLEFT", btnIn, "BOTTOMLEFT", 0, -5)
    btnRoll:SetOnClick(function()
        local drSession = addon.deathRollSession
        if drSession.canRoll and drSession.currentMax then
            RandomRoll(1, drSession.currentMax)
            drSession.canRoll = false
            addon:UpdateDeathRollUI()
        else
            addon:Warning("Cannot roll right now")
        end
    end)
    btnRoll:SetEnabled(false)
    frame.btnRoll = btnRoll

    -- Status label
    local statusLabel = PixelUI.CreateText(frame.content, "Waiting for game...", "gray")
    PixelUI.SetPoint(statusLabel, "TOPLEFT", btnRoll, "BOTTOMLEFT", 0, -10)
    frame.statusLabel = statusLabel

    -- Wager amount label
    local wagerLabel = PixelUI.CreateText(frame.content, "", "accent")
    PixelUI.SetPoint(wagerLabel, "TOPRIGHT", btnRoll, "BOTTOMRIGHT", 0, -10)
    frame.wagerLabel = wagerLabel

    -- Win/Loss Container
    local winLossContainer = PixelUI.CreateBorderedFrame(frame.content, nil, CONTENT_WIDTH, 150)
    PixelUI.SetPoint(winLossContainer, "TOPLEFT", statusLabel, "BOTTOMLEFT", 0, -10)
    frame.winLossContainer = winLossContainer

    -- Win/Loss scroll frame
    local winLossScroll = PixelUI.CreateScrollFrame(winLossContainer, "WRC_DR_WinLossScroll", CONTENT_WIDTH - 10, 140)
    PixelUI.SetPoint(winLossScroll, "TOPLEFT", 5, -5)
    frame.winLossScroll = winLossScroll
    frame.winLossRows = {}

    -- Session balance total
    local balanceLabel = PixelUI.CreateText(frame.content, "Balance: 0g", "white")
    PixelUI.SetPoint(balanceLabel, "TOPLEFT", winLossContainer, "BOTTOMLEFT", 0, -8)
    frame.balanceLabel = balanceLabel

    -- Hide by default
    frame:Hide()
end

-- Update UI state based on active DeathRoll session
function addon:UpdateDeathRollUI()
    local frame = addon.deathRollFrame
    if not frame then return end

    local session = addon.deathRollSession

    -- Update wager label
    if session.wagerAmount then
        frame.wagerLabel:SetText(string.format("Wager: %dg", session.wagerAmount))
    else
        frame.wagerLabel:SetText("")
    end

    -- Update Roll button text, state, and glow
    if session.canRoll and session.currentMax then
        frame.btnRoll:SetText(string.format("Roll %d", session.currentMax))
        frame.btnRoll:SetEnabled(true)
        if LCG then LCG.PixelGlow_Start(frame.btnRoll, {0.95, 0.55, 0.1, 0.9}, 6, 0.35, 7, 1) end
    else
        frame.btnRoll:SetText("Roll")
        frame.btnRoll:SetEnabled(false)
        if LCG then LCG.PixelGlow_Stop(frame.btnRoll) end
    end

    -- Update status label based on session state
    if session.sessionEnded then
        frame.statusLabel:SetText("Game ended")
    elseif session.canRoll then
        frame.statusLabel:SetText("Your turn!")
    elseif session.currentPlayer then
        -- Extract just the name from "Name-Realm"
        local opponentName = strsplit("-", session.currentPlayer)
        frame.statusLabel:SetText(string.format("%s's turn...", opponentName))
    elseif session.phase == "starter_roll" then
        frame.statusLabel:SetText("Roll 100 to determine starter")
    elseif session.sessionId then
        frame.statusLabel:SetText("Waiting...")
    else
        frame.statusLabel:SetText("Waiting for game...")
    end
end

-- Toggle checkpoint for an entry (marks "paid up to here")
function addon:ToggleDRCheckpoint(entryIndex)
    addon.deathRollSession.checkpoints = addon.deathRollSession.checkpoints or {}

    if addon.deathRollSession.checkpoints[entryIndex] then
        addon.deathRollSession.checkpoints[entryIndex] = nil
    else
        addon.deathRollSession.checkpoints[entryIndex] = true
    end

    self:UpdateDRWinLossDisplay()
end

-- Update win/loss display from history
function addon:UpdateDRWinLossDisplay()
    local frame = addon.deathRollFrame
    if not frame or not frame.winLossScroll then return end

    local history = addon.deathRollSession.winLossHistory
    local paidEntries = addon.deathRollSession.paidEntries or {}
    local checkpoints = addon.deathRollSession.checkpoints or {}
    local scrollChild = frame.winLossScroll.scrollContent
    local rowWidth = scrollChild:GetWidth() - 7

    -- Clear existing rows
    for _, row in ipairs(frame.winLossRows) do
        row:Hide()
    end

    -- Calculate total balance
    local totalBalance = 0

    -- Create/update rows (newest first)
    for i = #history, 1, -1 do
        local entry = history[i]
        local displayIdx = #history - i + 1
        local entryIndex = i
        local isPaid = paidEntries[entryIndex]
        local isCheckpoint = checkpoints[entryIndex]
        local isLoss = entry.amount < 0

        totalBalance = totalBalance + entry.amount

        local row = frame.winLossRows[displayIdx]

        -- Create row if needed
        if not row then
            row = CreateFrame("Button", nil, scrollChild)
            row:SetSize(rowWidth, 18)
            row:SetPoint("TOPLEFT", scrollChild, "TOPLEFT", 0, -(displayIdx - 1) * 20)

            -- Checkpoint checkbox (only for losses)
            row.checkbox = CreateFrame("Button", nil, row)
            row.checkbox:SetSize(14, 14)
            row.checkbox:SetPoint("LEFT", 2, 0)

            row.checkboxBg = row.checkbox:CreateTexture(nil, "BACKGROUND")
            row.checkboxBg:SetAllPoints()
            row.checkboxBg:SetTexture("Interface\\Buttons\\WHITE8x8")
            row.checkboxBg:SetVertexColor(0.15, 0.15, 0.15, 1)

            row.checkboxBorder = row.checkbox:CreateTexture(nil, "BORDER")
            row.checkboxBorder:SetPoint("TOPLEFT", -1, 1)
            row.checkboxBorder:SetPoint("BOTTOMRIGHT", 1, -1)
            row.checkboxBorder:SetTexture("Interface\\Buttons\\WHITE8x8")
            row.checkboxBorder:SetVertexColor(0, 0, 0, 1)

            row.checkmark = row.checkbox:CreateTexture(nil, "OVERLAY")
            row.checkmark:SetSize(10, 10)
            row.checkmark:SetPoint("CENTER")
            row.checkmark:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
            row.checkmark:Hide()

            row.opponentText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            row.opponentText:SetPoint("LEFT", row.checkbox, "RIGHT", 4, 0)
            row.opponentText:SetWidth(100)
            row.opponentText:SetJustifyH("LEFT")

            row.resultText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            row.resultText:SetPoint("RIGHT", -5, 0)
            row.resultText:SetWidth(70)
            row.resultText:SetJustifyH("RIGHT")

            frame.winLossRows[displayIdx] = row
        end

        row.entryData = entry
        row.entryIndex = entryIndex
        row.opponentText:SetText("vs " .. (entry.opponent or "???"))

        -- Configure checkbox visibility and state
        if isLoss and not isPaid then
            row.checkbox:Show()
            row.checkboxBg:Show()
            row.checkboxBorder:Show()

            if isCheckpoint then
                row.checkmark:Show()
                row.checkboxBg:SetVertexColor(0.2, 0.4, 0.2, 1)
            else
                row.checkmark:Hide()
                row.checkboxBg:SetVertexColor(0.15, 0.15, 0.15, 1)
            end

            row.checkbox:SetScript("OnClick", function()
                addon:ToggleDRCheckpoint(entryIndex)
            end)

            row.checkbox:SetScript("OnEnter", function(self)
                row.checkboxBg:SetVertexColor(0.25, 0.25, 0.25, 1)
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                if isCheckpoint then
                    GameTooltip:AddLine("Click to unmark checkpoint", 1, 1, 1)
                else
                    GameTooltip:AddLine("Click to mark as paid up to here", 1, 1, 1)
                end
                GameTooltip:Show()
            end)
            row.checkbox:SetScript("OnLeave", function()
                if isCheckpoint then
                    row.checkboxBg:SetVertexColor(0.2, 0.4, 0.2, 1)
                else
                    row.checkboxBg:SetVertexColor(0.15, 0.15, 0.15, 1)
                end
                GameTooltip:Hide()
            end)
        else
            row.checkbox:Hide()
            row.checkboxBg:Hide()
            row.checkboxBorder:Hide()
            row.checkmark:Hide()
        end

        -- Configure based on win/loss/paid status
        if isPaid then
            row.opponentText:SetTextColor(0.5, 0.5, 0.5)
            row.resultText:SetText(entry.amount .. "g |cFF00FF00\226\156\147|r")
            row.resultText:SetTextColor(0.5, 0.5, 0.5)
            local ht = row:GetHighlightTexture()
            if ht then ht:SetTexture(nil) end
            row:SetScript("OnMouseDown", nil)
        elseif isLoss then
            row.opponentText:SetTextColor(1, 1, 1)
            row.resultText:SetText(entry.amount .. "g")
            row.resultText:SetTextColor(0.9, 0.4, 0.4)
            row:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
            row:SetScript("OnMouseDown", function()
                if addon.InitiateDRPayment then
                    addon:InitiateDRPayment(entry)
                end
            end)
        else
            row.opponentText:SetTextColor(1, 1, 1)
            row.resultText:SetText("+" .. entry.amount .. "g")
            row.resultText:SetTextColor(0.4, 0.9, 0.4)
            local ht = row:GetHighlightTexture()
            if ht then ht:SetTexture(nil) end
            row:SetScript("OnMouseDown", nil)
        end

        row:Show()
    end

    scrollChild:SetHeight(math.max(1, #history * 20))

    if frame.balanceLabel then
        if totalBalance > 0 then
            frame.balanceLabel:SetText(string.format("Balance: |cFF66FF66+%dg|r", totalBalance))
        elseif totalBalance < 0 then
            frame.balanceLabel:SetText(string.format("Balance: |cFFFF6666%dg|r", totalBalance))
        else
            frame.balanceLabel:SetText("Balance: 0g")
        end
    end
end

-- ============================================================================
-- DeathRoll Payment (similar to SimpleDice but uses deathRollSession)
-- ============================================================================

---Calculate total owed to a specific opponent for DeathRoll
function addon:GetUnpaidDRDebtTo(opponentName)
    local totalOwed = 0
    local entries = {}
    local checkpoints = addon.deathRollSession.checkpoints or {}

    local lastCheckpointIdx = 0
    for i, entry in ipairs(addon.deathRollSession.winLossHistory) do
        if entry.opponent == opponentName and checkpoints[i] then
            lastCheckpointIdx = i
        end
    end

    for i, entry in ipairs(addon.deathRollSession.winLossHistory) do
        if entry.amount < 0
           and entry.opponent == opponentName
           and not addon.deathRollSession.paidEntries[i]
           and i > lastCheckpointIdx then
            totalOwed = totalOwed + math.abs(entry.amount)
            table.insert(entries, i)
        end
    end

    return totalOwed, entries
end

---Initiate payment for a DeathRoll loss entry
function addon:InitiateDRPayment(clickedEntry)
    local opponentName = clickedEntry.opponent

    if not opponentName then
        self:Warning("Cannot determine opponent name")
        return
    end

    local totalOwed, entryIndices = self:GetUnpaidDRDebtTo(opponentName)

    if totalOwed == 0 then
        self:Info("No unpaid debts to " .. opponentName)
        return
    end

    local copperOwed = totalOwed * 10000

    local hasEnough, shortfall = self:HasEnoughGold(copperOwed)
    if not hasEnough then
        local goldNeeded = math.ceil(shortfall / 10000)
        self:Warning(string.format("Not enough gold! You need %dg more.", goldNeeded))
        return
    end

    -- Store pending trade info (use special flag to identify as DeathRoll)
    addon.pendingTrade = {
        active = true,
        opponent = opponentName,
        amount = copperOwed,
        entries = entryIndices,
        isDeathRoll = true,  -- Flag to mark entries in correct session
    }

    if not self:IsTargeting(opponentName) then
        self:Info(string.format("Target %s first, then click again to pay %dg",
            opponentName, totalOwed))
        addon.pendingTrade.active = false
        return
    end

    if not self:IsTargetPlayer() then
        self:Warning("Target is not a player")
        addon.pendingTrade.active = false
        return
    end

    self:Info(string.format("Opening trade with %s for %dg...", opponentName, totalOwed))
    InitiateTrade("target")
end
