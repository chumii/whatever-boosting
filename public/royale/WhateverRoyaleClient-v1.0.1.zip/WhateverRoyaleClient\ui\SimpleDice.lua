--[[
    WhateverRoyaleClient - SimpleDice.lua
    Simple Dice UI frame using PixelUI
]]
local addonName, addon = ...
local PixelUI = addon.PixelUI
local LCG = LibStub and LibStub("LibCustomGlow-1.0", true)

-- Layout constants
local FRAME_WIDTH = 250
local FRAME_PADDING = 10
local CONTENT_WIDTH = FRAME_WIDTH - (FRAME_PADDING * 2) - 2  -- 228px usable

-- Create the SimpleDice Frame
function addon:CreateSimpleDiceFrame()
    local frame = PixelUI.CreateMainFrame(
        UIParent,
        "WRCSimpleDiceFrame",
        "Simple Dice",
        FRAME_WIDTH,
        310
    )
    PixelUI.SetPoint(frame, "CENTER")
    frame:SetTitleJustify("CENTER")

    -- Store frame reference in addon namespace
    addon.simpleDiceFrame = frame

    -- Button widths: two buttons + gap = content width
    local btnWidth = (CONTENT_WIDTH - 10) / 2  -- 109px each

    -- In Button
    local btnIn = PixelUI.CreateButton(frame.content, "In", "primary", btnWidth, 20)
    PixelUI.SetPoint(btnIn, "TOPLEFT", FRAME_PADDING, -10)
    btnIn:SetOnClick(function()
        SendChatMessage("in", addon.activeSession.channel or "PARTY")
    end)
    addon.simpleDiceFrame.btnIn = btnIn

    -- Out Button
    local btnOut = PixelUI.CreateButton(frame.content, "Out", "danger", btnWidth, 20)
    PixelUI.SetPoint(btnOut, "TOPLEFT", btnIn, "TOPRIGHT", 10, 0)
    btnOut:SetOnClick(function()
        SendChatMessage("out", addon.activeSession.channel or "PARTY")
    end)
    addon.simpleDiceFrame.btnOut = btnOut

    -- Roll Button (full width)
    local btnRoll = PixelUI.CreateButton(frame.content, "Roll", "accent", CONTENT_WIDTH, 25)
    PixelUI.SetPoint(btnRoll, "TOPLEFT", btnIn, "BOTTOMLEFT", 0, -5)
    btnRoll:SetOnClick(function()
        if addon.activeSession.canRoll and addon.activeSession.rollAmount then
            RandomRoll(1, addon.activeSession.rollAmount)
            addon.activeSession.canRoll = false
            addon:UpdateSimpleDiceUI()
        else
            addon:Warning("Cannot roll right now")
        end
    end)
    btnRoll:SetEnabled(false)
    addon.simpleDiceFrame.btnRoll = btnRoll

    -- Status label
    local statusLabel = PixelUI.CreateText(frame.content, "Waiting for round...", "gray")
    PixelUI.SetPoint(statusLabel, "TOPLEFT", btnRoll, "BOTTOMLEFT", 0, -10)
    addon.simpleDiceFrame.statusLabel = statusLabel

    -- Win/Loss Container (full width)
    local winLossContainer = PixelUI.CreateBorderedFrame(frame.content, nil, CONTENT_WIDTH, 150)
    PixelUI.SetPoint(winLossContainer, "TOPLEFT", statusLabel, "BOTTOMLEFT", 0, -10)
    addon.simpleDiceFrame.winLossContainer = winLossContainer

    -- Win/Loss scroll frame
    local winLossScroll = PixelUI.CreateScrollFrame(winLossContainer, "WRC_WinLossScroll", CONTENT_WIDTH - 10, 140)
    PixelUI.SetPoint(winLossScroll, "TOPLEFT", 5, -5)
    addon.simpleDiceFrame.winLossScroll = winLossScroll
    addon.simpleDiceFrame.winLossRows = {}

    -- Session balance total
    local balanceLabel = PixelUI.CreateText(frame.content, "Balance: 0g", "white")
    PixelUI.SetPoint(balanceLabel, "TOPLEFT", winLossContainer, "BOTTOMLEFT", 0, -8)
    addon.simpleDiceFrame.balanceLabel = balanceLabel

    -- Hide by default (will show when ROLL_NOW received)
    frame:Hide()
end

-- Update UI state based on active session
function addon:UpdateSimpleDiceUI()
    local frame = addon.simpleDiceFrame
    if not frame then return end

    local session = addon.activeSession

    -- Update Roll button text, state, and glow
    if session.canRoll and session.rollAmount then
        frame.btnRoll:SetText(string.format("Roll %d", session.rollAmount))
        frame.btnRoll:SetEnabled(true)
        if LCG then LCG.PixelGlow_Start(frame.btnRoll, {0.95, 0.55, 0.1, 0.9}, 6, 0.35, 7, 1) end
    else
        frame.btnRoll:SetText("Roll")
        frame.btnRoll:SetEnabled(false)
        if LCG then LCG.PixelGlow_Stop(frame.btnRoll) end
    end

    -- Update status label based on session/round state
    if session.sessionEnded then
        frame.statusLabel:SetText("Session ended")
    elseif session.canRoll then
        frame.statusLabel:SetText(string.format("Round %d - Roll now!", session.roundNumber or 0))
    elseif session.roundStatus == "completed" then
        frame.statusLabel:SetText(string.format("Round %d completed", session.roundNumber or 0))
    elseif session.sessionId then
        frame.statusLabel:SetText(string.format("Round %d - Waiting...", session.roundNumber or 0))
    else
        frame.statusLabel:SetText("Waiting for round...")
    end
end

-- Toggle checkpoint for an entry (marks "paid up to here")
function addon:ToggleCheckpoint(entryIndex)
    addon.activeSession.checkpoints = addon.activeSession.checkpoints or {}

    if addon.activeSession.checkpoints[entryIndex] then
        -- Remove this checkpoint
        addon.activeSession.checkpoints[entryIndex] = nil
    else
        -- Set checkpoint at this index
        addon.activeSession.checkpoints[entryIndex] = true
    end

    -- Refresh display
    self:UpdateWinLossDisplay()
end

-- Update win/loss display from history
function addon:UpdateWinLossDisplay()
    local frame = addon.simpleDiceFrame
    if not frame or not frame.winLossScroll then return end

    local history = addon.activeSession.winLossHistory
    local paidEntries = addon.activeSession.paidEntries or {}
    local checkpoints = addon.activeSession.checkpoints or {}
    local scrollChild = frame.winLossScroll.scrollContent
    local rowWidth = scrollChild:GetWidth() - 7  -- Account for scrollbar

    -- Clear existing rows
    for _, row in ipairs(frame.winLossRows) do
        row:Hide()
    end

    -- Calculate total balance
    local totalBalance = 0

    -- Create/update rows (newest first)
    for i = #history, 1, -1 do
        local entry = history[i]
        local displayIdx = #history - i + 1
        local entryIndex = i  -- Original index for paid tracking
        local isPaid = paidEntries[entryIndex]
        local isCheckpoint = checkpoints[entryIndex]
        local isLoss = entry.amount < 0

        totalBalance = totalBalance + entry.amount

        local row = frame.winLossRows[displayIdx]

        -- Create row if needed
        if not row then
            row = CreateFrame("Button", nil, scrollChild)
            row:SetSize(rowWidth, 18)
            row:SetPoint("TOPLEFT", scrollChild, "TOPLEFT", 0, -(displayIdx - 1) * 20)

            -- Checkpoint checkbox (only for losses)
            row.checkbox = CreateFrame("Button", nil, row)
            row.checkbox:SetSize(14, 14)
            row.checkbox:SetPoint("LEFT", 2, 0)

            -- Checkbox background
            row.checkboxBg = row.checkbox:CreateTexture(nil, "BACKGROUND")
            row.checkboxBg:SetAllPoints()
            row.checkboxBg:SetTexture("Interface\\Buttons\\WHITE8x8")
            row.checkboxBg:SetVertexColor(0.15, 0.15, 0.15, 1)

            -- Checkbox border
            row.checkboxBorder = row.checkbox:CreateTexture(nil, "BORDER")
            row.checkboxBorder:SetPoint("TOPLEFT", -1, 1)
            row.checkboxBorder:SetPoint("BOTTOMRIGHT", 1, -1)
            row.checkboxBorder:SetTexture("Interface\\Buttons\\WHITE8x8")
            row.checkboxBorder:SetVertexColor(0, 0, 0, 1)

            -- Checkbox checkmark
            row.checkmark = row.checkbox:CreateTexture(nil, "OVERLAY")
            row.checkmark:SetSize(10, 10)
            row.checkmark:SetPoint("CENTER")
            row.checkmark:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
            row.checkmark:Hide()

            -- Opponent text (after checkbox)
            row.opponentText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            row.opponentText:SetPoint("LEFT", row.checkbox, "RIGHT", 4, 0)
            row.opponentText:SetWidth(100)
            row.opponentText:SetJustifyH("LEFT")

            -- Result text (right side)
            row.resultText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            row.resultText:SetPoint("RIGHT", -5, 0)
            row.resultText:SetWidth(70)
            row.resultText:SetJustifyH("RIGHT")

            frame.winLossRows[displayIdx] = row
        end

        -- Store entry reference
        row.entryData = entry
        row.entryIndex = entryIndex

        -- Show opponent name with vs prefix
        row.opponentText:SetText("vs " .. (entry.opponent or "???"))

        -- Configure checkbox visibility and state
        if isLoss and not isPaid then
            -- Show checkbox for unpaid losses
            row.checkbox:Show()
            row.checkboxBg:Show()
            row.checkboxBorder:Show()

            if isCheckpoint then
                row.checkmark:Show()
                row.checkboxBg:SetVertexColor(0.2, 0.4, 0.2, 1)  -- Green tint when checked
            else
                row.checkmark:Hide()
                row.checkboxBg:SetVertexColor(0.15, 0.15, 0.15, 1)
            end

            -- Checkbox click handler
            row.checkbox:SetScript("OnClick", function()
                addon:ToggleCheckpoint(entryIndex)
            end)

            -- Hover effect for checkbox
            row.checkbox:SetScript("OnEnter", function(self)
                row.checkboxBg:SetVertexColor(0.25, 0.25, 0.25, 1)
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                if isCheckpoint then
                    GameTooltip:AddLine("Click to unmark checkpoint", 1, 1, 1)
                else
                    GameTooltip:AddLine("Click to mark as paid up to here", 1, 1, 1)
                end
                GameTooltip:Show()
            end)
            row.checkbox:SetScript("OnLeave", function()
                if isCheckpoint then
                    row.checkboxBg:SetVertexColor(0.2, 0.4, 0.2, 1)
                else
                    row.checkboxBg:SetVertexColor(0.15, 0.15, 0.15, 1)
                end
                GameTooltip:Hide()
            end)
        else
            -- Hide checkbox for wins and paid entries
            row.checkbox:Hide()
            row.checkboxBg:Hide()
            row.checkboxBorder:Hide()
            row.checkmark:Hide()
        end

        -- Configure based on win/loss/paid status
        if isPaid then
            -- Paid entry: dimmed with checkmark, not clickable
            row.opponentText:SetTextColor(0.5, 0.5, 0.5)
            row.resultText:SetText(entry.amount .. "g |cFF00FF00\226\156\147|r")  -- checkmark
            row.resultText:SetTextColor(0.5, 0.5, 0.5)
            local ht = row:GetHighlightTexture()
            if ht then ht:SetTexture(nil) end
            row:SetScript("OnMouseDown", nil)
        elseif isLoss then
            -- Unpaid loss: clickable with hover highlight
            row.opponentText:SetTextColor(1, 1, 1)
            row.resultText:SetText(entry.amount .. "g")
            row.resultText:SetTextColor(0.9, 0.4, 0.4)
            row:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
            row:SetScript("OnMouseDown", function()
                if addon.InitiatePayment then
                    addon:InitiatePayment(entry)
                end
            end)
        else
            -- Win: green, not clickable
            row.opponentText:SetTextColor(1, 1, 1)
            row.resultText:SetText("+" .. entry.amount .. "g")
            row.resultText:SetTextColor(0.4, 0.9, 0.4)
            -- Clear highlight by setting empty texture
            local ht = row:GetHighlightTexture()
            if ht then ht:SetTexture(nil) end
            row:SetScript("OnMouseDown", nil)
        end

        row:Show()
    end

    -- Update scroll height
    scrollChild:SetHeight(math.max(1, #history * 20))

    -- Update balance label
    if frame.balanceLabel then
        if totalBalance > 0 then
            frame.balanceLabel:SetText(string.format("Balance: |cFF66FF66+%dg|r", totalBalance))
        elseif totalBalance < 0 then
            frame.balanceLabel:SetText(string.format("Balance: |cFFFF6666%dg|r", totalBalance))
        else
            frame.balanceLabel:SetText("Balance: 0g")
        end
    end
end
