--[[
    WhateverRoyale - Database.lua
    SavedVariables management and database operations

    This module handles:
    - Database schema initialization
    - Session management queries
    - Character management and main/alt system
    - Statistics calculations and leaderboards
    - Database migration
]]

local addonName, addon = ...

-- ============================================================================
-- Session Management
-- ============================================================================

-- Generate unique session ID
function addon:GenerateSessionId()
    -- Ensure metadata table exists
    if not WhateverRoyaleDB then
        self:Error("Database not initialized")
        return nil
    end

    if not WhateverRoyaleDB.metadata then
        WhateverRoyaleDB.metadata = {
            lastSessionCounter = 0,
            lastSessionTimestamp = 0,
            totalSessionsCreated = 0,
            installDate = time(),
        }
    end

    local currentTime = time()

    if currentTime == WhateverRoyaleDB.metadata.lastSessionTimestamp then
        WhateverRoyaleDB.metadata.lastSessionCounter =
            WhateverRoyaleDB.metadata.lastSessionCounter + 1
    else
        WhateverRoyaleDB.metadata.lastSessionCounter = 1
        WhateverRoyaleDB.metadata.lastSessionTimestamp = currentTime
    end

    WhateverRoyaleDB.metadata.totalSessionsCreated =
        WhateverRoyaleDB.metadata.totalSessionsCreated + 1

    return string.format("%d_%d", currentTime,
        WhateverRoyaleDB.metadata.lastSessionCounter)
end

-- Get session by ID
function addon:GetSession(sessionId)
    return WhateverRoyaleDB.sessions[sessionId]
end

-- Get all active sessions
function addon:GetActiveSessions()
    local activeSessions = {}

    for sessionId, session in pairs(WhateverRoyaleDB.sessions) do
        if session.status == "active" then
            table.insert(activeSessions, session)
        end
    end

    return activeSessions
end

-- Recover abandoned sessions (called on addon load)
function addon:RecoverAbandonedSessions()
    if not WhateverRoyaleDB or not WhateverRoyaleDB.sessions then
        return 0
    end

    local recoveredCount = 0

    for sessionId, session in pairs(WhateverRoyaleDB.sessions) do
        if session.status == "active" then
            session.status = "abandoned"
            session.endTime = time()

            -- Calculate stats for completed rounds only
            self:RecalculateSessionStats(sessionId)

            recoveredCount = recoveredCount + 1

            self:Debug("Recovered abandoned session: " .. sessionId)
        end
    end

    if recoveredCount > 0 then
        self:Warning(string.format(
            "Recovered %d abandoned session(s) from previous crash.",
            recoveredCount
        ))
    end
end

-- Recalculate session statistics
function addon:RecalculateSessionStats(sessionId)
    local session = self:GetSession(sessionId)
    if not session then return end

    -- Reset session stats
    session.sessionStats = {
        totalRounds = 0,
        totalPayouts = 0,
        leaderboard = {},
    }

    -- Recalculate from completed rounds only
    for roundNum, round in pairs(session.rounds) do
        if round.status == "completed" and round.results then
            local results = round.results

            session.sessionStats.totalRounds = session.sessionStats.totalRounds + 1
            session.sessionStats.totalPayouts =
                session.sessionStats.totalPayouts + results.payoutAmount

            session.sessionStats.leaderboard[results.winner] =
                (session.sessionStats.leaderboard[results.winner] or 0) + results.payoutAmount

            session.sessionStats.leaderboard[results.loser] =
                (session.sessionStats.leaderboard[results.loser] or 0) - results.payoutAmount
        end
    end
end

-- ============================================================================
-- Character Management
-- ============================================================================

-- Get current player's character ID
function addon:GetCurrentCharacterId()
    local name = UnitName("player")
    local realm = GetRealmName()
    return string.format("%s-%s", name, realm)
end

-- Get or create character entry
function addon:GetOrCreateCharacter(characterId)
    if not WhateverRoyaleDB.characters[characterId] then
        local name, realm = strsplit("-", characterId)

        WhateverRoyaleDB.characters[characterId] = {
            characterId = characterId,
            name = name,
            realm = realm,
            characterType = "unlinked",
            mainCharacter = nil,
            firstSeen = time(),
            lastSeen = time(),
            stats = {
                overall = self:CreateEmptyStats(),
                byGame = {},
                sessionHistory = {},
            },
        }

        self:Debug("Created new character entry: " .. characterId)
    else
        -- Update last seen
        WhateverRoyaleDB.characters[characterId].lastSeen = time()
    end

    return WhateverRoyaleDB.characters[characterId]
end

-- Create empty stats structure
function addon:CreateEmptyStats()
    return {
        totalRounds = 0,
        totalSessions = 0,
        roundsWon = 0,
        roundsLost = 0,
        winRate = 0.0,
        totalGoldWon = 0,
        totalGoldLost = 0,
        netBalance = 0,
        biggestWin = 0,
        biggestLoss = 0,
        bestSession = 0,
        worstSession = 0,
    }
end

-- Validate if two characters can be linked
function addon:CanLinkCharacters(altId, mainId)
    local altChar = WhateverRoyaleDB.characters[altId]
    local mainChar = WhateverRoyaleDB.characters[mainId]

    if not altChar or not mainChar then
        return false, "One or both characters not found"
    end

    if altChar.characterId == mainChar.characterId then
        return false, "Cannot link character to itself"
    end

    if mainChar.characterType == "alt" then
        return false, "Cannot link to an alt character"
    end

    if altChar.characterType == "main" then
        -- Check if this main has any alts linked to it
        for _, char in pairs(WhateverRoyaleDB.characters) do
            if char.mainCharacter == altId then
                return false, "This character is a main with linked alts"
            end
        end
    end

    return true
end

-- Link alt to main
function addon:LinkAltToMain(altId, mainId)
    local canLink, errorMsg = self:CanLinkCharacters(altId, mainId)

    if not canLink then
        return false, errorMsg
    end

    local altChar = WhateverRoyaleDB.characters[altId]
    local mainChar = WhateverRoyaleDB.characters[mainId]

    -- Update alt character
    altChar.characterType = "alt"
    altChar.mainCharacter = mainId

    -- Ensure main is marked as main
    if mainChar.characterType == "unlinked" then
        mainChar.characterType = "main"
    end

    self:Info(string.format("Linked %s as alt to main %s", altId, mainId))

    return true
end

-- Unlink alt from main
function addon:UnlinkAlt(altId)
    local altChar = WhateverRoyaleDB.characters[altId]

    if not altChar or altChar.characterType ~= "alt" then
        return false, "Character is not an alt"
    end

    altChar.characterType = "unlinked"
    altChar.mainCharacter = nil

    self:Info(string.format("Unlinked %s (now unlinked)", altId))

    return true
end

-- Set character type (main/alt/unlinked)
function addon:SetCharacterType(characterId, charType)
    local character = WhateverRoyaleDB.characters[characterId]

    if not character then
        return false, "Character not found"
    end

    if charType ~= "main" and charType ~= "alt" and charType ~= "unlinked" then
        return false, "Invalid character type"
    end

    character.characterType = charType

    return true
end

-- ============================================================================
-- Statistics
-- ============================================================================

-- Get merged stats for a character (combines main + alts if main)
function addon:GetMergedStats(characterId, gameType)
    local character = WhateverRoyaleDB.characters[characterId]

    if not character then
        return nil
    end

    -- Start with character's own stats
    local mergedStats = self:CreateEmptyStats()
    local sourceStats

    if gameType then
        sourceStats = character.stats.byGame[gameType] or self:CreateEmptyStats()
    else
        sourceStats = character.stats.overall
    end

    -- Deep copy source stats
    for key, value in pairs(sourceStats) do
        mergedStats[key] = value
    end

    -- If this is a main, add all alt stats
    if character.characterType == "main" then
        for charId, char in pairs(WhateverRoyaleDB.characters) do
            if char.characterType == "alt" and char.mainCharacter == characterId then
                local altStats

                if gameType then
                    altStats = char.stats.byGame[gameType] or self:CreateEmptyStats()
                else
                    altStats = char.stats.overall
                end

                -- Aggregate stats
                mergedStats.totalRounds = mergedStats.totalRounds + altStats.totalRounds
                mergedStats.totalSessions = mergedStats.totalSessions + altStats.totalSessions
                mergedStats.roundsWon = mergedStats.roundsWon + altStats.roundsWon
                mergedStats.roundsLost = mergedStats.roundsLost + altStats.roundsLost
                mergedStats.totalGoldWon = mergedStats.totalGoldWon + altStats.totalGoldWon
                mergedStats.totalGoldLost = mergedStats.totalGoldLost + altStats.totalGoldLost
                mergedStats.netBalance = mergedStats.netBalance + altStats.netBalance

                -- Update extremes
                if altStats.biggestWin > mergedStats.biggestWin then
                    mergedStats.biggestWin = altStats.biggestWin
                end
                if altStats.biggestLoss > mergedStats.biggestLoss then
                    mergedStats.biggestLoss = altStats.biggestLoss
                end
                if altStats.bestSession > mergedStats.bestSession then
                    mergedStats.bestSession = altStats.bestSession
                end
                if altStats.worstSession < mergedStats.worstSession or
                   mergedStats.worstSession == 0 then
                    mergedStats.worstSession = altStats.worstSession
                end
            end
        end

        -- Recalculate win rate
        if mergedStats.totalRounds > 0 then
            mergedStats.winRate = mergedStats.roundsWon / mergedStats.totalRounds
        end
    end

    return mergedStats
end

-- Get leaderboard data with filtering and sorting
function addon:GetLeaderboard(options)
    --[[
        options = {
            gameType = "simpleDice" or nil (all games),
            mergeMains = true/false,
            sortBy = "netBalance" or "winRate" or "totalRounds",
            limit = 10 (top N),
            minRounds = 5 (minimum rounds to qualify)
        }
    ]]
    options = options or {}
    local sortBy = options.sortBy or "netBalance"
    local mergeMains = options.mergeMains
    if mergeMains == nil and WhateverRoyaleDB and WhateverRoyaleDB.settings then
        mergeMains = WhateverRoyaleDB.settings.mergeMainsAndAlts
    end

    local leaderboardData = {}

    -- Safety check: return empty table if characters not initialized
    if not WhateverRoyaleDB or not WhateverRoyaleDB.characters then
        return leaderboardData
    end

    for charId, character in pairs(WhateverRoyaleDB.characters) do
        local stats
        local displayName = charId

        if mergeMains then
            -- Handle main/alt merging
            if character.characterType == "main" then
                -- Add main with merged stats (includes all alts)
                stats = self:GetMergedStats(charId, options.gameType)
                displayName = charId
            elseif character.characterType == "alt" then
                -- Skip alts entirely - they're already in main's merged stats
                stats = nil
            else
                -- Unlinked character - use their own stats
                if options.gameType then
                    stats = character.stats.byGame[options.gameType]
                else
                    stats = character.stats.overall
                end
            end
        else
            -- No merging - use individual character stats
            if options.gameType then
                stats = character.stats.byGame[options.gameType]
            else
                stats = character.stats.overall
            end
        end

        -- Apply filters and skip if no stats
        if stats then
            -- Skip players with 0 rounds (they haven't actually played)
            local meetsMinRounds = not options.minRounds or stats.totalRounds >= options.minRounds
            local hasPlayed = stats.totalRounds > 0

            if meetsMinRounds and hasPlayed then
                table.insert(leaderboardData, {
                    characterId = displayName,
                    stats = stats,
                })
            end
        end
    end

    -- Sort leaderboard
    table.sort(leaderboardData, function(a, b)
        return a.stats[sortBy] > b.stats[sortBy]
    end)

    -- Apply limit
    if options.limit and #leaderboardData > options.limit then
        local limitedData = {}
        for i = 1, options.limit do
            limitedData[i] = leaderboardData[i]
        end
        leaderboardData = limitedData
    end

    return leaderboardData
end

-- Format a gold amount with sign and dot-separated thousands (e.g. +25.000g)
function addon:FormatBalance(balance)
    local abs = math.abs(balance)
    local numText = tostring(abs):reverse():gsub("(%d%d%d)", "%1."):reverse():gsub("^%.", "")
    if balance >= 0 then
        return "+" .. numText .. "g"
    else
        return "-" .. numText .. "g"
    end
end

-- Post overall leaderboard (top/flop N) to chat, always with mains+alts merged
function addon:PostOverallLeaderboard(n, channel)
    n = math.max(1, math.min(n or 5, 10))
    channel = channel or "RAID"

    local allData = self:GetLeaderboard({
        mergeMains = true,
        sortBy = "netBalance",
    })

    if #allData == 0 then
        self:Warning("Keine Statistikdaten vorhanden.")
        return
    end

    local topCount = math.min(n, #allData)

    -- Top N (highest net balance), one line per rank
    self:AnnounceToChannel(channel, string.format(
        "[WR] Gesamtrangliste (Mains+Alts) — Top %d:", topCount))
    for i = 1, topCount do
        local e = allData[i]
        local name = strsplit("-", e.characterId)
        self:AnnounceToChannel(channel, string.format("#%d %s: %s", i, name, self:FormatBalance(e.stats.netBalance)))
    end

    -- Flop N (lowest net balance = last N in desc-sorted list, shown worst-first), one line per rank
    self:AnnounceToChannel(channel, string.format("[WR] Flop %d:", topCount))
    for i = #allData, math.max(#allData - n + 1, 1), -1 do
        local e = allData[i]
        local name = strsplit("-", e.characterId)
        local rank = #allData - i + 1
        self:AnnounceToChannel(channel, string.format("#%d %s: %s", rank, name, self:FormatBalance(e.stats.netBalance)))
    end
end

-- Update character statistics (placeholder - will be implemented in SessionManager)
function addon:UpdateCharacterStats(characterId)
    -- This will be fully implemented in SessionManager.lua
    -- For now, just ensure character exists
    self:GetOrCreateCharacter(characterId)
end

-- ============================================================================
-- Session Deletion
-- ============================================================================

-- Delete one or more sessions and rebuild all character stats from scratch.
-- This is the only correct approach because high-water-mark fields like
-- biggestWin/worstSession cannot be "undone" without a full replay.
function addon:DeleteSessions(ids)
    for _, sid in ipairs(ids) do
        WhateverRoyaleDB.sessions[sid] = nil
    end
    self:RebuildAllCharacterStats()
end

-- Wipe all character stats and replay every remaining completed/abandoned session.
function addon:RebuildAllCharacterStats()
    for _, char in pairs(WhateverRoyaleDB.characters) do
        char.stats.overall      = self:CreateEmptyStats()
        char.stats.byGame       = {}
        char.stats.sessionHistory = {}
    end

    for sessionId, session in pairs(WhateverRoyaleDB.sessions) do
        if session.status == "completed" or session.status == "abandoned" then
            for _, round in ipairs(session.rounds) do
                if round.status == "completed" and round.results then
                    self:UpdateCharacterStatsFromRound(session, round)
                end
            end
            self:UpdateSessionCompletionStats(sessionId)
        end
    end
end

-- ============================================================================
-- Database Migration
-- ============================================================================

-- Migrate database from older versions
function addon:MigrateDatabase()
    if not WhateverRoyaleDB.schemaVersion then
        -- Migrating from v1.0.0 (no schema version)
        self:Info("Migrating database from v1.0.0 to v2.0.0...")

        -- Backup old settings if they exist
        local oldSettings = WhateverRoyaleDB.settings or {}

        -- Initialize new schema structure (will be done in OnLoad)
        -- Just update version info
        WhateverRoyaleDB.version = "2.0.0"
        WhateverRoyaleDB.schemaVersion = 2

        self:Success("Database migrated successfully to v2.0.0")
    elseif WhateverRoyaleDB.schemaVersion == 2 then
        -- Migrate v2 → v3: exportedAt field added to sessions (nil = not yet exported)
        -- No data writes needed; nil is the correct default for all existing sessions.
        WhateverRoyaleDB.schemaVersion = 3
        self:Info("Database migrated to v3 (export tracking)")
    elseif WhateverRoyaleDB.schemaVersion == 3 then
        -- Already on current schema
        return
    else
        -- Future migrations would go here
        self:Warning("Unknown schema version: " .. tostring(WhateverRoyaleDB.schemaVersion))
    end
end
