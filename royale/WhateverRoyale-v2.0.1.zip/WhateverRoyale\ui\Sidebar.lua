--[[
    WhateverRoyale - Sidebar.lua
    Tab switching logic (simplified - buttons are in MainFrame.lua now)
]]

local addonName, addon = ...
local PixelUI = addon.PixelUI

-- Tab switching function with animated resize
function addon:SwitchTab(tabName)
    addon:Debug("Switching to tab: " .. tabName)

    -- Hide all tabs
    for name, tab in pairs(addon.tabs or {}) do
        tab:Hide()
    end

    -- Show selected tab
    if addon.tabs and addon.tabs[tabName] then
        local tab = addon.tabs[tabName]
        tab:Show()
    end

    -- Update button highlights
    if addon.mainFrame and addon.mainFrame.tabButtons then
        for name, btn in pairs(addon.mainFrame.tabButtons) do
            if name == tabName then
                btn:SetBackdropBorderColor(PixelUI.GetColorRGB("accent"))
            else
                btn:SetBackdropBorderColor(PixelUI.GetColorRGB("gray"))
            end
        end
    end

    -- Animate resize to required height for this tab
    local requiredHeight = addon.TAB_HEIGHTS[tabName] or 500
    local currentHeight = addon.mainFrame:GetHeight()

    -- Resize if height changed (both grow and shrink)
    if requiredHeight ~= currentHeight then
        PixelUI.AnimatedResize(addon.mainFrame, addon.mainFrame:GetWidth(), requiredHeight)
    end
end
