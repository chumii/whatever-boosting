--[[
    WhateverRoyale - StatisticsTab.lua
    Statistics and leaderboard display using PixelUI

    Features:
    - Filterable leaderboards (by game, main/alt merging, sort order)
    - Minimum rounds filter
    - Clickable rows to show player details
]]

local _, addon = ...
local PixelUI = addon.PixelUI

-- Layout constants
local TAB_PADDING = 12
local SECTION_SPACING = 16
local ELEMENT_SPACING = 8
local TABLE_WIDTH = 706
local TABLE_HEIGHT = 220
local DETAILS_HEIGHT = 100

function addon:CreateStatisticsTab(parent)
    -- Tab frame (fills parent content area)
    local tab = PixelUI.CreateFrame(parent, nil, 730, 610)
    tab:SetAllPoints(parent)
    tab:Hide()

    -- Title
    local title = PixelUI.CreateText(tab, "Statistics & Leaderboards", "white")
    title:SetFontObject("GameFontNormalLarge")
    PixelUI.SetPoint(title, "TOPLEFT", TAB_PADDING, -TAB_PADDING)

    -- ========================================================================
    -- Filters Section
    -- ========================================================================

    local filtersHeader = PixelUI.CreateText(tab, "Filters", "accent")
    PixelUI.SetPoint(filtersHeader, "TOPLEFT", title, "BOTTOMLEFT", 0, -SECTION_SPACING)

    -- Filter Row 1: Game Type + Merge Checkbox
    local gameLabel = PixelUI.CreateText(tab, "Game Type:", "text")
    PixelUI.SetPoint(gameLabel, "TOPLEFT", filtersHeader, "BOTTOMLEFT", 0, -ELEMENT_SPACING)
    gameLabel:SetWidth(80)
    gameLabel:SetJustifyH("LEFT")

    local gameDropdown = PixelUI.CreateDropdown(tab, 130)
    PixelUI.SetPoint(gameDropdown, "LEFT", gameLabel, "RIGHT", 8, 0)

    gameDropdown:SetItems({
        {text = "All Games", value = "all"},
        {text = "Simple Dice", value = "simpleDice"},
        {text = "Death-Roll", value = "deathRoll"},
    })

    gameDropdown:SetSelected("all")
    gameDropdown:SetOnSelect(function(value)
        if value == "all" then
            tab.selectedGameType = nil
        else
            tab.selectedGameType = value
        end
        addon:RefreshLeaderboard(tab)
    end)

    tab.gameDropdown = gameDropdown
    tab.selectedGameType = nil

    local mergeCheckbox = PixelUI.CreateCheckButton(
        tab,
        "Merge Mains & Alts",
        function(_)
            addon:RefreshLeaderboard(tab)
        end
    )
    PixelUI.SetPoint(mergeCheckbox, "LEFT", gameDropdown, "RIGHT", 20, 0)

    local defaultMerge = true
    if WhateverRoyaleDB and WhateverRoyaleDB.settings then
        defaultMerge = WhateverRoyaleDB.settings.mergeMainsAndAlts
    end
    mergeCheckbox:SetChecked(defaultMerge)
    tab.mergeCheckbox = mergeCheckbox

    -- Filter Row 2: Sort By + Min Rounds Slider
    local sortLabel = PixelUI.CreateText(tab, "Sort By:", "text")
    PixelUI.SetPoint(sortLabel, "TOPLEFT", gameLabel, "BOTTOMLEFT", 0, -12)
    sortLabel:SetWidth(80)
    sortLabel:SetJustifyH("LEFT")

    local sortValue = PixelUI.CreateText(tab, "Net Balance", "text_dim")
    PixelUI.SetPoint(sortValue, "LEFT", sortLabel, "RIGHT", 8, 0)
    sortValue:SetWidth(90)

    local minRoundsLabel = PixelUI.CreateText(tab, "Min Rounds: 0", "text")
    PixelUI.SetPoint(minRoundsLabel, "LEFT", sortValue, "RIGHT", 30, 0)
    minRoundsLabel:SetWidth(100)

    local minRoundsSlider = PixelUI.CreateSlider(tab, "", 180, 0, 50, 1, false)
    PixelUI.SetPoint(minRoundsSlider, "LEFT", minRoundsLabel, "RIGHT", 8, 0)
    minRoundsSlider:SetValue(0)

    minRoundsSlider:SetOnValueChanged(function(value)
        minRoundsLabel:SetText("Min Rounds: " .. math.floor(value))
        addon:RefreshLeaderboard(tab)
    end)
    tab.minRoundsSlider = minRoundsSlider

    -- ========================================================================
    -- Leaderboard Table
    -- ========================================================================

    local leaderboardHeader = PixelUI.CreateText(tab, "Leaderboard", "accent")
    PixelUI.SetPoint(leaderboardHeader, "TOPLEFT", sortLabel, "BOTTOMLEFT", 0, -SECTION_SPACING)

    -- Post-to-Chat controls on the same row as the leaderboard header
    local postNLabel = PixelUI.CreateText(tab, "Top/Flop:", "text_dim")
    PixelUI.SetPoint(postNLabel, "LEFT", leaderboardHeader, "RIGHT", 20, 0)

    local postNItems = {}
    for i = 1, 10 do
        table.insert(postNItems, {text = tostring(i), value = i})
    end
    local postNDropdown = PixelUI.CreateDropdown(tab, 55)
    PixelUI.SetPoint(postNDropdown, "LEFT", postNLabel, "RIGHT", 4, 0)
    postNDropdown:SetItems(postNItems)
    postNDropdown:SetSelected(5)
    tab.postNDropdown = postNDropdown

    local postChannelDropdown = PixelUI.CreateDropdown(tab, 70)
    PixelUI.SetPoint(postChannelDropdown, "LEFT", postNDropdown, "RIGHT", 8, 0)
    postChannelDropdown:SetItems({
        {text = "Raid",  value = "RAID"},
        {text = "Party", value = "PARTY"},
        {text = "Guild", value = "GUILD"},
    })
    postChannelDropdown:SetSelected("RAID")
    tab.postChannelDropdown = postChannelDropdown

    local btnPostLb = PixelUI.CreateButton(tab, "Post to Chat", "secondary", 90, 22)
    PixelUI.SetPoint(btnPostLb, "LEFT", postChannelDropdown, "RIGHT", 8, 0)
    btnPostLb:SetOnClick(function()
        local n = tab.postNDropdown:GetSelected() or 5
        local channel = tab.postChannelDropdown:GetSelected() or "RAID"
        addon:PostOverallLeaderboard(n, channel)
    end)

    -- Table container with background
    local tableContainer = CreateFrame("Frame", nil, tab, "BackdropTemplate")
    tableContainer:SetSize(TABLE_WIDTH, TABLE_HEIGHT + 24)
    PixelUI.SetPoint(tableContainer, "TOPLEFT", leaderboardHeader, "BOTTOMLEFT", 0, -ELEMENT_SPACING)
    tableContainer:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    tableContainer:SetBackdropColor(0.08, 0.08, 0.08, 1.0)
    tableContainer:SetBackdropBorderColor(0.20, 0.20, 0.20, 1.0)
    tab.tableContainer = tableContainer

    -- Table header row background
    local headerBg = tableContainer:CreateTexture(nil, "BACKGROUND", nil, 1)
    headerBg:SetColorTexture(0.12, 0.12, 0.12, 1.0)
    headerBg:SetPoint("TOPLEFT", tableContainer, "TOPLEFT", 1, -1)
    headerBg:SetPoint("TOPRIGHT", tableContainer, "TOPRIGHT", -1, -1)
    headerBg:SetHeight(22)

    -- Table Headers
    local headerRank = PixelUI.CreateText(tableContainer, "Rank", "gray")
    headerRank:SetPoint("TOPLEFT", tableContainer, "TOPLEFT", 12, -5)
    headerRank:SetWidth(40)
    headerRank:SetJustifyH("LEFT")

    local headerName = PixelUI.CreateText(tableContainer, "Character", "gray")
    headerName:SetPoint("LEFT", headerRank, "RIGHT", 10, 0)
    headerName:SetWidth(200)
    headerName:SetJustifyH("LEFT")

    local headerBalance = PixelUI.CreateText(tableContainer, "Net Balance", "gray")
    headerBalance:SetPoint("LEFT", headerName, "RIGHT", 10, 0)
    headerBalance:SetWidth(120)
    headerBalance:SetJustifyH("RIGHT")

    local headerWinRate = PixelUI.CreateText(tableContainer, "Win Rate", "gray")
    headerWinRate:SetPoint("LEFT", headerBalance, "RIGHT", 20, 0)
    headerWinRate:SetWidth(80)
    headerWinRate:SetJustifyH("CENTER")

    local headerRounds = PixelUI.CreateText(tableContainer, "Rounds", "gray")
    headerRounds:SetPoint("LEFT", headerWinRate, "RIGHT", 20, 0)
    headerRounds:SetWidth(60)
    headerRounds:SetJustifyH("CENTER")

    -- Scroll frame inside container
    local lbScrollFrame = PixelUI.CreateScrollFrame(tableContainer, "WR_LBScroll", TABLE_WIDTH - 2, TABLE_HEIGHT)
    lbScrollFrame:SetPoint("TOPLEFT", tableContainer, "TOPLEFT", 1, -24)

    tab.lbScrollChild = lbScrollFrame.scrollContent
    tab.lbRows = {}

    -- ========================================================================
    -- Player Details Section
    -- ========================================================================

    local detailsHeader = PixelUI.CreateText(tab, "Player Details", "accent")
    PixelUI.SetPoint(detailsHeader, "TOPLEFT", tableContainer, "BOTTOMLEFT", 0, -SECTION_SPACING)

    -- Details container with background
    local detailsContainer = CreateFrame("Frame", nil, tab, "BackdropTemplate")
    detailsContainer:SetSize(TABLE_WIDTH, DETAILS_HEIGHT)
    PixelUI.SetPoint(detailsContainer, "TOPLEFT", detailsHeader, "BOTTOMLEFT", 0, -ELEMENT_SPACING)
    detailsContainer:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    detailsContainer:SetBackdropColor(0.08, 0.08, 0.08, 1.0)
    detailsContainer:SetBackdropBorderColor(0.20, 0.20, 0.20, 1.0)
    tab.detailsContainer = detailsContainer

    -- Player Details Label
    local detailsLabel = PixelUI.CreateText(detailsContainer, "Select a player to view details", "text_dim")
    PixelUI.SetPoint(detailsLabel, "TOPLEFT", detailsContainer, "TOPLEFT", 12, -10)

    -- Player Details Text
    local detailsText = PixelUI.CreateText(detailsContainer, "", "text")
    PixelUI.SetPoint(detailsText, "TOPLEFT", detailsLabel, "BOTTOMLEFT", 0, -8)
    detailsText:SetWidth(TABLE_WIDTH - 24)
    detailsText:SetJustifyH("LEFT")
    detailsText:SetJustifyV("TOP")
    detailsText:SetSpacing(4)

    tab.detailsLabel = detailsLabel
    tab.detailsText = detailsText

    -- Initial leaderboard population
    self:RefreshLeaderboard(tab)

    -- Register tab
    addon.tabs = addon.tabs or {}
    addon.tabs.statistics = tab

    return tab
end

-- Refresh leaderboard data
function addon:RefreshLeaderboard(tab)
    if not tab or not tab.lbScrollChild then return end

    local mergeMains = tab.mergeCheckbox:GetChecked()
    local minRounds = tab.minRoundsSlider:GetValue()

    local gameType = tab.selectedGameType

    self:Debug(string.format("RefreshLeaderboard - gameType: %s, mergeMains: %s, minRounds: %s",
        tostring(gameType), tostring(mergeMains), tostring(minRounds)))

    local leaderboardData = self:GetLeaderboard({
        gameType = gameType,
        mergeMains = mergeMains,
        sortBy = "netBalance",
        minRounds = minRounds,
    })

    self:Debug(string.format("RefreshLeaderboard - found %d entries", #leaderboardData))

    -- Clear existing rows
    for _, row in ipairs(tab.lbRows) do
        row:Hide()
    end

    -- Create/update rows
    for i, entry in ipairs(leaderboardData) do
        local row = tab.lbRows[i]
        if not row then
            row = self:CreateStatisticsRow(tab.lbScrollChild, i)
            tab.lbRows[i] = row
        end

        -- Get character name (without realm)
        local characterName = strsplit("-", entry.characterId)

        -- Format data
        local netBalance = entry.stats.netBalance
        local balanceText
        if netBalance > 0 then
            balanceText = string.format("+%d|cFFFFD700g|r", netBalance)
        else
            balanceText = string.format("%d|cFFFFD700g|r", netBalance)
        end

        local winRateText = string.format("%.1f%%", entry.stats.winRate * 100)

        -- Update row
        row.rank:SetText(tostring(i))
        row.name:SetText(characterName)
        row.balance:SetText(balanceText)
        row.winRate:SetText(winRateText)
        row.rounds:SetText(tostring(entry.stats.totalRounds))

        -- Color balance (muted colors)
        if netBalance > 0 then
            row.balance:SetTextColor(0.45, 0.75, 0.45)
        elseif netBalance < 0 then
            row.balance:SetTextColor(0.85, 0.40, 0.40)
        else
            row.balance:SetTextColor(0.55, 0.55, 0.55)
        end

        -- Color win rate (muted colors)
        if entry.stats.winRate > 0.5 then
            row.winRate:SetTextColor(0.45, 0.75, 0.45)
        elseif entry.stats.winRate < 0.5 then
            row.winRate:SetTextColor(0.85, 0.40, 0.40)
        else
            row.winRate:SetTextColor(0.55, 0.55, 0.55)
        end

        -- Make row clickable
        row:SetScript("OnMouseDown", function()
            addon:ShowPlayerDetails(tab, entry.characterId, entry.stats)
        end)

        row:Show()
    end

    -- Update scroll content height
    local contentHeight = math.max(1, #leaderboardData * 22)
    tab.lbScrollChild:SetHeight(contentHeight)

    -- Show/hide "no data" message
    if #leaderboardData == 0 then
        if not tab.noDataText then
            tab.noDataText = PixelUI.CreateText(
                tab.lbScrollChild,
                "No statistics data yet.\nPlay some games to see leaderboards!",
                "text_dim"
            )
            PixelUI.SetPoint(tab.noDataText, "CENTER", tab.lbScrollChild, "CENTER", 0, 0)
        end
        tab.noDataText:Show()
    else
        if tab.noDataText then
            tab.noDataText:Hide()
        end
    end
end

-- Create a leaderboard row
function addon:CreateStatisticsRow(parent, index)
    local rowWidth = TABLE_WIDTH - 10
    local row = CreateFrame("Button", nil, parent)
    row:SetSize(rowWidth, 20)
    row:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, -(index - 1) * 22)

    -- Highlight on hover
    row:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")

    -- Alternating background
    if index % 2 == 0 then
        local bg = row:CreateTexture(nil, "BACKGROUND")
        bg:SetColorTexture(0.10, 0.10, 0.10, 1.0)
        bg:SetAllPoints(row)
    end

    row.rank = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.rank:SetPoint("LEFT", row, "LEFT", 8, 0)
    row.rank:SetWidth(40)
    row.rank:SetJustifyH("LEFT")
    row.rank:SetTextColor(0.55, 0.55, 0.55)

    row.name = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.name:SetPoint("LEFT", row.rank, "RIGHT", 10, 0)
    row.name:SetWidth(200)
    row.name:SetJustifyH("LEFT")

    row.balance = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.balance:SetPoint("LEFT", row.name, "RIGHT", 10, 0)
    row.balance:SetWidth(120)
    row.balance:SetJustifyH("RIGHT")

    row.winRate = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.winRate:SetPoint("LEFT", row.balance, "RIGHT", 20, 0)
    row.winRate:SetWidth(80)
    row.winRate:SetJustifyH("CENTER")

    row.rounds = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.rounds:SetPoint("LEFT", row.winRate, "RIGHT", 20, 0)
    row.rounds:SetWidth(60)
    row.rounds:SetJustifyH("CENTER")
    row.rounds:SetTextColor(0.55, 0.55, 0.55)

    return row
end

-- Show player details
function addon:ShowPlayerDetails(tab, characterId, stats)
    if not tab or not tab.detailsText then return end

    local characterName = strsplit("-", characterId)

    tab.detailsLabel:SetText("Player Details - " .. characterName)
    tab.detailsLabel:SetTextColor(0.90, 0.90, 0.90)

    local detailsText = string.format(
        "Total Rounds: %d  |  Total Sessions: %d  |  Rounds Won: |cFF73BF73%d|r  |  Rounds Lost: |cFFD96666%d|r  |  Win Rate: %.1f%%\n" ..
        "\n" ..
        "Total Gold Won: %d|cFFFFD700g|r  |  Total Gold Lost: %d|cFFFFD700g|r  |  Net Balance: %s%d|cFFFFD700g|r\n" ..
        "\n" ..
        "Biggest Win: %d|cFFFFD700g|r  |  Biggest Loss: %d|cFFFFD700g|r  |  Best Session: %s%d|cFFFFD700g|r  |  Worst Session: %s%d|cFFFFD700g|r",
        stats.totalRounds,
        stats.totalSessions,
        stats.roundsWon,
        stats.roundsLost,
        stats.winRate * 100,
        stats.totalGoldWon,
        stats.totalGoldLost,
        stats.netBalance >= 0 and "+" or "",
        stats.netBalance,
        stats.biggestWin,
        stats.biggestLoss,
        stats.bestSession >= 0 and "+" or "",
        stats.bestSession,
        stats.worstSession >= 0 and "+" or "",
        stats.worstSession
    )

    tab.detailsText:SetText(detailsText)
    tab.detailsText:Show()
end
