--[[
    WhateverRoyale - SessionFrame.lua
    Floating session window for tracking rounds and leaderboards using PixelUI
]]

local _, addon = ...
local PixelUI = addon.PixelUI

-- Storage for session frames
addon.sessionFrames = addon.sessionFrames or {}

-- Layout constants
local FRAME_WIDTH = 400
local FRAME_PADDING = 12
local SECTION_SPACING = 12
local ELEMENT_SPACING = 6
local BUTTON_WIDTH = 110
local BUTTON_HEIGHT = 26
local TABLE_HEIGHT = 160
local LB_TABLE_HEIGHT = 130
local BUTTONS_AREA_HEIGHT = BUTTON_HEIGHT * 2 + ELEMENT_SPACING  -- two button rows

-- ============================================================================
-- Session Frame Creation
-- ============================================================================

function addon:CreateSessionFrame(sessionId)
    local session = self:GetSession(sessionId)
    if not session then
        self:Error("Cannot create frame - session not found")
        return
    end

    local frameName = "WRSessionFrame_" .. sessionId

    -- Create main session window with game-specific title
    local title = session.gameType == "deathRoll" and "Death-Roll Session" or "Simple Dice Session"
    local frame = PixelUI.CreateMainFrame(
        UIParent,
        frameName,
        title,
        FRAME_WIDTH,
        560
    )
    PixelUI.SetPoint(frame, "CENTER", UIParent, "CENTER", 200, 0)
    frame:SetTitleJustify("LEFT")

    -- Store session ID reference
    frame.sessionId = sessionId

    -- Create UI elements (all parented to frame.content)
    self:CreateSessionActionButtons(frame, sessionId)

    -- Create appropriate table based on game type
    if session.gameType == "deathRoll" then
        self:CreateDeathRollHistoryTable(frame, sessionId)
    else
        self:CreateRoundTable(frame, sessionId)
    end

    self:CreateSessionLeaderboard(frame, sessionId)

    -- Store reference
    addon.sessionFrames[sessionId] = frame

    -- Override close button: always properly end the session instead of just hiding
    if frame.closeButton then
        frame.closeButton:SetScript("OnClick", function()
            addon:CloseSession(sessionId, true)
        end)
    end

    frame:Show()

    self:Debug("Session frame created for " .. sessionId)

    return frame
end

-- ============================================================================
-- Action Buttons (Top)
-- ============================================================================

function addon:CreateSessionActionButtons(frame, sessionId)
    local session = addon:GetSession(sessionId)
    local isDeathRoll = session.gameType == "deathRoll"
    local content = frame.content

    -- Calculate centering
    local buttonWidth = isDeathRoll and (BUTTON_WIDTH * 2 + ELEMENT_SPACING) or (BUTTON_WIDTH * 3 + ELEMENT_SPACING * 2)
    local startX = (FRAME_WIDTH - 2 - buttonWidth) / 2

    -- Start Sign Up Button
    local btnStartSignUp = PixelUI.CreateButton(content, "Start Sign-Up", "primary", BUTTON_WIDTH, BUTTON_HEIGHT)
    PixelUI.SetPoint(btnStartSignUp, "TOPLEFT", content, "TOPLEFT", startX, -FRAME_PADDING)
    btnStartSignUp:SetOnClick(function()
        addon:StartSignUp(sessionId)
    end)
    frame.btnStartSignUp = btnStartSignUp

    -- Last Call Button - Hidden for Death-Roll
    local btnLastCall = PixelUI.CreateButton(content, "Last Call", "warning", BUTTON_WIDTH, BUTTON_HEIGHT)
    PixelUI.SetPoint(btnLastCall, "LEFT", btnStartSignUp, "RIGHT", ELEMENT_SPACING, 0)
    btnLastCall:SetOnClick(function()
        addon:LastCall(sessionId)
    end)
    frame.btnLastCall = btnLastCall

    if isDeathRoll then
        btnLastCall:Hide()
    end

    -- Start Rolling Button
    local btnStartRolling = PixelUI.CreateButton(content, "Start Rolling", "accent", BUTTON_WIDTH, BUTTON_HEIGHT)
    if isDeathRoll then
        PixelUI.SetPoint(btnStartRolling, "LEFT", btnStartSignUp, "RIGHT", ELEMENT_SPACING, 0)
    else
        PixelUI.SetPoint(btnStartRolling, "LEFT", btnLastCall, "RIGHT", ELEMENT_SPACING, 0)
    end
    btnStartRolling:SetOnClick(function()
        addon:StartRolling(sessionId)
    end)
    frame.btnStartRolling = btnStartRolling

    -- Row 2: Remind + End Session (always 2 buttons, centered)
    local row2Width = BUTTON_WIDTH * 2 + ELEMENT_SPACING
    local row2StartX = (FRAME_WIDTH - 2 - row2Width) / 2
    local row2Y = -(FRAME_PADDING + BUTTON_HEIGHT + ELEMENT_SPACING)

    local btnRemind = PixelUI.CreateButton(content, "Remind", "warning", BUTTON_WIDTH, BUTTON_HEIGHT)
    PixelUI.SetPoint(btnRemind, "TOPLEFT", content, "TOPLEFT", row2StartX, row2Y)
    btnRemind:SetOnClick(function()
        addon:AnnounceWaitingPlayers(sessionId)
    end)
    frame.btnRemind = btnRemind

    local btnEndSession = PixelUI.CreateButton(content, "End Session", "danger", BUTTON_WIDTH, BUTTON_HEIGHT)
    PixelUI.SetPoint(btnEndSession, "LEFT", btnRemind, "RIGHT", ELEMENT_SPACING, 0)
    btnEndSession:SetOnClick(function()
        addon:CloseSession(sessionId, true)
    end)
    frame.btnEndSession = btnEndSession
end

-- ============================================================================
-- Round Table (Simple Dice)
-- ============================================================================

function addon:CreateRoundTable(frame, sessionId)
    local content = frame.content
    local tableWidth = FRAME_WIDTH - 2 - (FRAME_PADDING * 2)

    -- "Round" header - positioned below both button rows
    local roundLabel = PixelUI.CreateText(content, "Round", "accent")
    PixelUI.SetPoint(roundLabel, "TOPLEFT", content, "TOPLEFT", FRAME_PADDING, -(FRAME_PADDING + BUTTONS_AREA_HEIGHT + SECTION_SPACING))
    frame.roundLabel = roundLabel

    -- Table container with background
    local tableContainer = CreateFrame("Frame", nil, content, "BackdropTemplate")
    tableContainer:SetSize(tableWidth, TABLE_HEIGHT + 24)
    PixelUI.SetPoint(tableContainer, "TOPLEFT", content, "TOPLEFT", FRAME_PADDING, -(FRAME_PADDING + BUTTONS_AREA_HEIGHT + SECTION_SPACING + 16))
    tableContainer:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    tableContainer:SetBackdropColor(0.08, 0.08, 0.08, 1.0)
    tableContainer:SetBackdropBorderColor(0.20, 0.20, 0.20, 1.0)
    frame.roundTableContainer = tableContainer

    -- Table header row background
    local headerBg = tableContainer:CreateTexture(nil, "BACKGROUND", nil, 1)
    headerBg:SetColorTexture(0.12, 0.12, 0.12, 1.0)
    headerBg:SetPoint("TOPLEFT", 1, -1)
    headerBg:SetPoint("TOPRIGHT", -1, -1)
    headerBg:SetHeight(22)

    -- Table headers
    local headerNum = PixelUI.CreateText(tableContainer, "#", "gray")
    headerNum:SetPoint("TOPLEFT", 12, -5)
    headerNum:SetWidth(24)
    headerNum:SetJustifyH("LEFT")

    local headerName = PixelUI.CreateText(tableContainer, "Player", "gray")
    headerName:SetPoint("LEFT", headerNum, "RIGHT", 8, 0)
    headerName:SetWidth(180)
    headerName:SetJustifyH("LEFT")

    local headerStatus = PixelUI.CreateText(tableContainer, "Roll", "gray")
    headerStatus:SetPoint("TOPRIGHT", -12, -5)
    headerStatus:SetWidth(60)
    headerStatus:SetJustifyH("RIGHT")

    -- Scroll frame inside container
    local scrollFrame = PixelUI.CreateScrollFrame(tableContainer, "WR_RoundScroll", tableWidth - 2, TABLE_HEIGHT)
    scrollFrame:SetPoint("TOPLEFT", 1, -24)

    frame.roundScrollChild = scrollFrame.scrollContent
    frame.roundRows = {}
end

-- ============================================================================
-- Death-Roll History Table
-- ============================================================================

function addon:CreateDeathRollHistoryTable(frame, sessionId)
    local content = frame.content
    local tableWidth = FRAME_WIDTH - 2 - (FRAME_PADDING * 2)

    -- "Roll History" header - positioned below both button rows
    local historyHeader = PixelUI.CreateText(content, "Roll History", "accent")
    PixelUI.SetPoint(historyHeader, "TOPLEFT", content, "TOPLEFT", FRAME_PADDING, -(FRAME_PADDING + BUTTONS_AREA_HEIGHT + SECTION_SPACING))
    frame.historyLabel = historyHeader

    -- Table container with background
    local tableContainer = CreateFrame("Frame", nil, content, "BackdropTemplate")
    tableContainer:SetSize(tableWidth, TABLE_HEIGHT + 24)
    PixelUI.SetPoint(tableContainer, "TOPLEFT", content, "TOPLEFT", FRAME_PADDING, -(FRAME_PADDING + BUTTONS_AREA_HEIGHT + SECTION_SPACING + 16))
    tableContainer:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    tableContainer:SetBackdropColor(0.08, 0.08, 0.08, 1.0)
    tableContainer:SetBackdropBorderColor(0.20, 0.20, 0.20, 1.0)
    frame.historyTableContainer = tableContainer

    -- Table header row background
    local headerBg = tableContainer:CreateTexture(nil, "BACKGROUND", nil, 1)
    headerBg:SetColorTexture(0.12, 0.12, 0.12, 1.0)
    headerBg:SetPoint("TOPLEFT", 1, -1)
    headerBg:SetPoint("TOPRIGHT", -1, -1)
    headerBg:SetHeight(22)

    -- Table headers
    local headerPlayer1 = PixelUI.CreateText(tableContainer, "Player 1", "gray")
    headerPlayer1:SetPoint("TOPLEFT", 12, -5)
    headerPlayer1:SetWidth(150)
    headerPlayer1:SetJustifyH("LEFT")

    local headerPlayer2 = PixelUI.CreateText(tableContainer, "Player 2", "gray")
    headerPlayer2:SetPoint("TOPRIGHT", -12, -5)
    headerPlayer2:SetWidth(150)
    headerPlayer2:SetJustifyH("RIGHT")

    -- Scroll frame inside container
    local scrollFrame = PixelUI.CreateScrollFrame(tableContainer, "WR_DeathRollHistory", tableWidth - 2, TABLE_HEIGHT)
    scrollFrame:SetPoint("TOPLEFT", 1, -24)

    frame.historyScrollChild = scrollFrame.scrollContent
    frame.historyRows = {}
end

-- ============================================================================
-- Session Leaderboard
-- ============================================================================

function addon:CreateSessionLeaderboard(frame, sessionId)
    local content = frame.content
    local tableWidth = FRAME_WIDTH - 2 - (FRAME_PADDING * 2)

    -- Get reference to the first table container
    local firstTableContainer = frame.roundTableContainer or frame.historyTableContainer

    -- "Session Leaderboard" header - positioned below first table
    local sessionLabel = PixelUI.CreateText(content, "Session Leaderboard", "accent")
    PixelUI.SetPoint(sessionLabel, "TOPLEFT", firstTableContainer, "BOTTOMLEFT", 0, -SECTION_SPACING)

    -- Table container with background
    local tableContainer = CreateFrame("Frame", nil, content, "BackdropTemplate")
    tableContainer:SetSize(tableWidth, LB_TABLE_HEIGHT + 24)
    PixelUI.SetPoint(tableContainer, "TOPLEFT", sessionLabel, "BOTTOMLEFT", 0, -ELEMENT_SPACING)
    tableContainer:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    tableContainer:SetBackdropColor(0.08, 0.08, 0.08, 1.0)
    tableContainer:SetBackdropBorderColor(0.20, 0.20, 0.20, 1.0)
    frame.lbTableContainer = tableContainer

    -- Table header row background
    local headerBg = tableContainer:CreateTexture(nil, "BACKGROUND", nil, 1)
    headerBg:SetColorTexture(0.12, 0.12, 0.12, 1.0)
    headerBg:SetPoint("TOPLEFT", 1, -1)
    headerBg:SetPoint("TOPRIGHT", -1, -1)
    headerBg:SetHeight(22)

    -- Table headers
    local headerNum = PixelUI.CreateText(tableContainer, "#", "gray")
    headerNum:SetPoint("TOPLEFT", 12, -5)
    headerNum:SetWidth(24)
    headerNum:SetJustifyH("LEFT")

    local headerName = PixelUI.CreateText(tableContainer, "Player", "gray")
    headerName:SetPoint("LEFT", headerNum, "RIGHT", 8, 0)
    headerName:SetWidth(180)
    headerName:SetJustifyH("LEFT")

    local headerWinnings = PixelUI.CreateText(tableContainer, "Winnings", "gray")
    headerWinnings:SetPoint("TOPRIGHT", -12, -5)
    headerWinnings:SetWidth(80)
    headerWinnings:SetJustifyH("RIGHT")

    -- Scroll frame inside container
    local scrollFrame = PixelUI.CreateScrollFrame(tableContainer, "WR_SessionLBScroll", tableWidth - 2, LB_TABLE_HEIGHT)
    scrollFrame:SetPoint("TOPLEFT", 1, -24)

    frame.lbScrollChild = scrollFrame.scrollContent
    frame.lbRows = {}

    -- Post buttons below table (centered)
    local btnWidth = 100
    local btnSpacing = 8
    local totalBtnWidth = (btnWidth * 3) + (btnSpacing * 2)
    local btnStartX = (tableWidth - totalBtnWidth) / 2

    local btnPostTop = PixelUI.CreateButton(content, "Post Top 5", "secondary", btnWidth, BUTTON_HEIGHT)
    PixelUI.SetPoint(btnPostTop, "TOPLEFT", tableContainer, "BOTTOMLEFT", btnStartX, -ELEMENT_SPACING)
    btnPostTop:SetOnClick(function()
        addon:PostLeaderboard(sessionId, "top", 5)
    end)

    local btnPostFlop = PixelUI.CreateButton(content, "Post Flop 5", "secondary", btnWidth, BUTTON_HEIGHT)
    PixelUI.SetPoint(btnPostFlop, "LEFT", btnPostTop, "RIGHT", btnSpacing, 0)
    btnPostFlop:SetOnClick(function()
        addon:PostLeaderboard(sessionId, "flop", 5)
    end)

    local btnPostBoth = PixelUI.CreateButton(content, "Post Both", "secondary", btnWidth, BUTTON_HEIGHT)
    PixelUI.SetPoint(btnPostBoth, "LEFT", btnPostFlop, "RIGHT", btnSpacing, 0)
    btnPostBoth:SetOnClick(function()
        addon:PostLeaderboard(sessionId, "both", 5)
    end)
end

-- ============================================================================
-- Update Functions
-- ============================================================================

function addon:UpdateRoundTable(sessionId)
    local frame = addon.sessionFrames[sessionId]
    if not frame then return end

    local session = self:GetSession(sessionId)
    if not session then return end

    local currentRound = session.rounds[#session.rounds]

    -- Update round label
    if currentRound then
        frame.roundLabel:SetText("Round " .. currentRound.roundNumber)
    else
        frame.roundLabel:SetText("Round")
    end

    -- Clear existing rows
    for _, row in ipairs(frame.roundRows) do
        row:Hide()
    end

    if not currentRound then return end

    -- Create/update rows for signed-up players
    local rowIndex = 1
    for characterId, _ in pairs(currentRound.signedUp) do
        local row = frame.roundRows[rowIndex]
        if not row then
            row = self:CreateRoundRow(frame.roundScrollChild, rowIndex)
            frame.roundRows[rowIndex] = row
        end

        local playerName = strsplit("-", characterId)
        local status = "in"
        if currentRound.rolls[characterId] then
            status = tostring(currentRound.rolls[characterId].roll)
        elseif currentRound.status == "rolling" then
            status = "..."
        end

        row.num:SetText(rowIndex)
        row.name:SetText(playerName)
        row.status:SetText(status)

        if currentRound.rolls[characterId] then
            row.status:SetTextColor(0.45, 0.75, 0.45)
        elseif currentRound.status == "rolling" then
            row.status:SetTextColor(0.70, 0.60, 0.25)
        else
            row.status:SetTextColor(0.90, 0.90, 0.90)
        end

        row:Show()
        rowIndex = rowIndex + 1
    end

    local contentHeight = math.max(1, (rowIndex - 1) * 22)
    frame.roundScrollChild:SetHeight(contentHeight)
end

function addon:UpdateDeathRollHistory(sessionId)
    local frame = addon.sessionFrames[sessionId]
    if not frame or not frame.historyScrollChild then return end

    local session = self:GetSession(sessionId)
    if not session then return end

    local currentRound = session.rounds[#session.rounds]
    if not currentRound or not currentRound.deathRollState then return end

    local drState = currentRound.deathRollState
    local tableWidth = FRAME_WIDTH - 2 - (FRAME_PADDING * 2) - 10

    -- Update history label
    if currentRound then
        local signedUpCount = 0
        for _ in pairs(currentRound.signedUp) do
            signedUpCount = signedUpCount + 1
        end

        if currentRound.status == "signup" then
            frame.historyLabel:SetText(string.format("Round %d - Sign-Up (%d/2)", currentRound.roundNumber, signedUpCount))
        else
            frame.historyLabel:SetText("Roll History - Round " .. currentRound.roundNumber)
        end
    end

    -- Clear existing history rows
    for _, row in ipairs(frame.historyRows) do
        row:Hide()
    end

    -- During sign-up phase
    if currentRound.status == "signup" then
        local row = frame.historyRows[1]
        if not row then
            row = CreateFrame("Frame", nil, frame.historyScrollChild)
            row:SetSize(tableWidth, 20)
            row:SetPoint("TOPLEFT", 0, 0)

            row.player1Roll = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            row.player1Roll:SetPoint("LEFT", 8, 0)
            row.player1Roll:SetWidth(150)
            row.player1Roll:SetJustifyH("LEFT")

            row.player2Roll = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            row.player2Roll:SetPoint("RIGHT", -8, 0)
            row.player2Roll:SetWidth(150)
            row.player2Roll:SetJustifyH("RIGHT")

            frame.historyRows[1] = row
        end

        if drState.player1 then
            local name1 = strsplit("-", drState.player1)
            row.player1Roll:SetText(name1 .. " (IN)")
            row.player1Roll:SetTextColor(0.45, 0.75, 0.45)
        else
            row.player1Roll:SetText("Waiting...")
            row.player1Roll:SetTextColor(0.55, 0.55, 0.55)
        end

        if drState.player2 then
            local name2 = strsplit("-", drState.player2)
            row.player2Roll:SetText(name2 .. " (IN)")
            row.player2Roll:SetTextColor(0.45, 0.75, 0.45)
        else
            row.player2Roll:SetText("Waiting...")
            row.player2Roll:SetTextColor(0.55, 0.55, 0.55)
        end

        row:Show()
        frame.historyScrollChild:SetHeight(22)
        return
    end

    -- Populate history (latest first)
    local history = drState.rollHistory
    for i = #history, 1, -1 do
        local rollEntry = history[i]
        local displayIndex = #history - i + 1

        local row = frame.historyRows[displayIndex]
        if not row then
            row = CreateFrame("Frame", nil, frame.historyScrollChild)
            row:SetSize(tableWidth, 20)
            row:SetPoint("TOPLEFT", 0, -(displayIndex - 1) * 22)

            if displayIndex % 2 == 0 then
                local bg = row:CreateTexture(nil, "BACKGROUND")
                bg:SetColorTexture(0.10, 0.10, 0.10, 1.0)
                bg:SetAllPoints()
            end

            row.player1Roll = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            row.player1Roll:SetPoint("LEFT", 8, 0)
            row.player1Roll:SetWidth(150)
            row.player1Roll:SetJustifyH("LEFT")

            row.player2Roll = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            row.player2Roll:SetPoint("RIGHT", -8, 0)
            row.player2Roll:SetWidth(150)
            row.player2Roll:SetJustifyH("RIGHT")

            frame.historyRows[displayIndex] = row
        end

        if rollEntry.player == drState.player1 then
            row.player1Roll:SetText(rollEntry.roll)
            row.player1Roll:SetTextColor(rollEntry.roll == 1 and 0.85 or 0.90, rollEntry.roll == 1 and 0.40 or 0.90, rollEntry.roll == 1 and 0.40 or 0.90)
            row.player2Roll:SetText("")
        else
            row.player2Roll:SetText(rollEntry.roll)
            row.player2Roll:SetTextColor(rollEntry.roll == 1 and 0.85 or 0.90, rollEntry.roll == 1 and 0.40 or 0.90, rollEntry.roll == 1 and 0.40 or 0.90)
            row.player1Roll:SetText("")
        end

        row:Show()
    end

    frame.historyScrollChild:SetHeight(math.max(1, #history * 22))
end

function addon:CreateRoundRow(parent, index)
    local tableWidth = FRAME_WIDTH - 2 - (FRAME_PADDING * 2) - 10
    local row = CreateFrame("Frame", nil, parent)
    row:SetSize(tableWidth, 20)
    row:SetPoint("TOPLEFT", 0, -(index - 1) * 22)

    if index % 2 == 0 then
        local bg = row:CreateTexture(nil, "BACKGROUND")
        bg:SetColorTexture(0.10, 0.10, 0.10, 1.0)
        bg:SetAllPoints()
    end

    row.num = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.num:SetPoint("LEFT", 8, 0)
    row.num:SetWidth(24)
    row.num:SetTextColor(0.55, 0.55, 0.55)

    row.name = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.name:SetPoint("LEFT", row.num, "RIGHT", 8, 0)
    row.name:SetWidth(180)
    row.name:SetJustifyH("LEFT")

    row.status = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.status:SetPoint("RIGHT", -8, 0)
    row.status:SetWidth(60)
    row.status:SetJustifyH("RIGHT")

    return row
end

function addon:UpdateSessionLeaderboard(sessionId)
    local frame = addon.sessionFrames[sessionId]
    if not frame then return end

    local session = self:GetSession(sessionId)
    if not session then return end

    for _, row in ipairs(frame.lbRows) do
        row:Hide()
    end

    local sortedPlayers = {}
    for characterId, winnings in pairs(session.sessionStats.leaderboard) do
        table.insert(sortedPlayers, {id = characterId, winnings = winnings})
    end
    table.sort(sortedPlayers, function(a, b) return a.winnings > b.winnings end)

    for i, playerData in ipairs(sortedPlayers) do
        local row = frame.lbRows[i]
        if not row then
            row = self:CreateLeaderboardRow(frame.lbScrollChild, i)
            frame.lbRows[i] = row
        end

        local playerName = strsplit("-", playerData.id)
        local winningsText = playerData.winnings > 0
            and string.format("+%d|cFFFFD700g|r", playerData.winnings)
            or string.format("%d|cFFFFD700g|r", playerData.winnings)

        row.num:SetText(i)
        row.name:SetText(playerName)
        row.winnings:SetText(winningsText)

        if playerData.winnings > 0 then
            row.winnings:SetTextColor(0.45, 0.75, 0.45)
        elseif playerData.winnings < 0 then
            row.winnings:SetTextColor(0.85, 0.40, 0.40)
        else
            row.winnings:SetTextColor(0.55, 0.55, 0.55)
        end

        row:Show()
    end

    frame.lbScrollChild:SetHeight(math.max(1, #sortedPlayers * 22))
end

function addon:CreateLeaderboardRow(parent, index)
    local tableWidth = FRAME_WIDTH - 2 - (FRAME_PADDING * 2) - 10
    local row = CreateFrame("Frame", nil, parent)
    row:SetSize(tableWidth, 20)
    row:SetPoint("TOPLEFT", 0, -(index - 1) * 22)

    if index % 2 == 0 then
        local bg = row:CreateTexture(nil, "BACKGROUND")
        bg:SetColorTexture(0.10, 0.10, 0.10, 1.0)
        bg:SetAllPoints()
    end

    row.num = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.num:SetPoint("LEFT", 8, 0)
    row.num:SetWidth(24)
    row.num:SetTextColor(0.55, 0.55, 0.55)

    row.name = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.name:SetPoint("LEFT", row.num, "RIGHT", 8, 0)
    row.name:SetWidth(180)
    row.name:SetJustifyH("LEFT")

    row.winnings = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.winnings:SetPoint("RIGHT", -8, 0)
    row.winnings:SetWidth(80)
    row.winnings:SetJustifyH("RIGHT")

    return row
end

-- ============================================================================
-- Session Frame Update
-- ============================================================================

function addon:UpdateSessionFrame(sessionId)
    local frame = addon.sessionFrames[sessionId]
    if not frame then return end

    local session = self:GetSession(sessionId)
    if not session then return end

    if session.gameType == "deathRoll" then
        self:UpdateDeathRollHistory(sessionId)
    else
        self:UpdateRoundTable(sessionId)
    end

    self:UpdateSessionLeaderboard(sessionId)
end

-- ============================================================================
-- Remind: announce players who haven't rolled yet
-- ============================================================================

function addon:AnnounceWaitingPlayers(sessionId)
    local session = self:GetSession(sessionId)
    if not session then return end

    local currentRound = session.rounds[#session.rounds]
    if not currentRound or currentRound.status ~= "rolling" then
        self:Warning("Nicht in der Roll-Phase.")
        return
    end

    if session.gameType == "deathRoll" then
        local drState = currentRound.deathRollState
        if drState and drState.currentPlayer then
            local name = strsplit("-", drState.currentPlayer)
            self:AnnounceToChannel(session.channel,
                string.format("ÖY %s: /roll %d", name, drState.expectedMax))
        end
    else
        local missing = self:GetMissingPlayers(sessionId, currentRound.roundNumber)
        if #missing == 0 then
            self:Info("Alle Spieler haben bereits gewürfelt!")
            return
        end
        self:AnnounceToChannel(session.channel, "ÖY DU: " .. table.concat(missing, ", "))
    end
end

-- ============================================================================
-- Leaderboard Posting
-- ============================================================================

function addon:PostLeaderboard(sessionId, type, count)
    local session = self:GetSession(sessionId)
    if not session then return end

    local sortedPlayers = {}
    for characterId, winnings in pairs(session.sessionStats.leaderboard) do
        table.insert(sortedPlayers, {id = characterId, winnings = winnings})
    end
    table.sort(sortedPlayers, function(a, b) return a.winnings > b.winnings end)

    local messages = {}

    if type == "top" or type == "both" then
        table.insert(messages, "WhateverRoyale Leaderboard - Top " .. count)
        for i = 1, math.min(count, #sortedPlayers) do
            local playerName = strsplit("-", sortedPlayers[i].id)
            local sign = sortedPlayers[i].winnings >= 0 and "+" or ""
            table.insert(messages, string.format("%d. %s - %s%dg", i, playerName, sign, sortedPlayers[i].winnings))
        end
    end

    if type == "flop" or type == "both" then
        if type == "both" then
            table.insert(messages, " ")
        end
        table.insert(messages, "WhateverRoyale Leaderboard - Flop " .. count)
        local startIdx = math.max(1, #sortedPlayers - count + 1)
        for i = #sortedPlayers, startIdx, -1 do
            local rank = #sortedPlayers - i + 1
            local playerName = strsplit("-", sortedPlayers[i].id)
            local sign = sortedPlayers[i].winnings >= 0 and "+" or ""
            table.insert(messages, string.format("%d. %s - %s%dg", rank, playerName, sign, sortedPlayers[i].winnings))
        end
    end

    for _, msg in ipairs(messages) do
        self:AnnounceToChannel(session.channel, msg)
    end
end
