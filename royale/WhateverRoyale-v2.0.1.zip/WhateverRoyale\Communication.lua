--[[
    WhateverRoyale - Communication.lua
    Addon message communication between WhateverRoyale (host) and WhateverRoyaleClient

    Uses WoW's addon messaging system:
    - C_ChatInfo.RegisterAddonMessagePrefix() to register our prefix
    - C_ChatInfo.SendAddonMessage() to send messages
    - CHAT_MSG_ADDON event to receive messages

    Message Protocol:
    - Prefix: "WR" (WhateverRoyale)
    - Format: "TYPE:DATA" (colon-separated)
    - Types: TEST, ROUND_START, ROLL_NOW, etc.
]]

local addonName, addon = ...

-- Message prefix (max 16 characters)
addon.MESSAGE_PREFIX = "WR"

-- Register the addon message prefix
local registered = C_ChatInfo.RegisterAddonMessagePrefix(addon.MESSAGE_PREFIX)
if not registered then
    addon:Warning("Failed to register addon message prefix")
end

-- ============================================================================
-- Message Sending
-- ============================================================================

---Send an addon message to the specified channel
---@param messageType string The message type (e.g., "TEST", "ROUND_START")
---@param data string|nil Optional data payload
---@param channel string|nil Channel to send on ("PARTY", "RAID", "GUILD", "WHISPER")
---@param target string|nil Required for WHISPER channel
function addon:SendAddonMessage(messageType, data, channel, target)
    local message = messageType
    if data and data ~= "" then
        message = messageType .. ":" .. data
    end

    channel = channel or "PARTY"

    local success = C_ChatInfo.SendAddonMessage(addon.MESSAGE_PREFIX, message, channel, target)

    if success then
        self:Debug(string.format("Sent addon message: [%s] %s to %s", channel, message, target or "all"))
    else
        self:Debug(string.format("Failed to send addon message: [%s] %s", channel, message))
    end

    return success
end

-- ============================================================================
-- Message Receiving
-- ============================================================================

---Handle incoming addon messages
---@param prefix string The addon message prefix
---@param message string The message content
---@param channel string The distribution channel
---@param sender string The sender's name
function addon:HandleAddonMessage(prefix, message, channel, sender)
    -- Only process our messages
    if prefix ~= addon.MESSAGE_PREFIX then return end

    -- Parse message type and data
    local msgType, data = strsplit(":", message, 2)

    self:Debug(string.format("Received addon message from %s [%s]: %s = %s",
        sender, channel, msgType, data or "nil"))

    -- Route to specific handlers based on message type
    if msgType == "TEST" then
        self:Info(string.format("Test message from %s: %s", sender, data or ""))

    -- Client sign-in/sign-out requests
    elseif msgType == "SIGN_IN" then
        -- Client wants to sign in for the active round
        self:Debug(string.format("SIGN_IN from %s", sender))
        if self.ProcessSignUp then
            self:ProcessSignUp(sender, true)
        end

    elseif msgType == "SIGN_OUT" then
        -- Client wants to sign out from the active round
        self:Debug(string.format("SIGN_OUT from %s", sender))
        if self.ProcessSignUp then
            self:ProcessSignUp(sender, false)
        end

    elseif msgType:find("^WRSYNC_") then
        if self.HandleSyncMessage then
            self:HandleSyncMessage(msgType, data, channel, sender)
        end
    end
end
