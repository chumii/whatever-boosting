--[[
    WhateverRoyale - MainFrame.lua
    Main UI frame using PixelUI
]]

local addonName, addon = ...
local PixelUI = addon.PixelUI

-- Define required heights for each tab (content height + buttons + padding)
addon.TAB_HEIGHTS = {
    settings  = 500,  -- Smallest tab
    dice      = 500,  -- Simple form
    deathroll = 500,  -- Death-Roll game
    statistics = 650, -- Needs more space for leaderboard
    mainalt   = 650,  -- Needs space for character list
    export    = 580,  -- Session export list
}

-- Create the main frame
function addon:CreateMainFrame()
    -- Use PixelUI.CreateMainFrame
    local frame = PixelUI.CreateMainFrame(
        UIParent,
        "WRMainFrame",
        "WhateverRoyale",
        750,
        500  -- Initial height
    )
    PixelUI.SetPoint(frame, "CENTER")
    frame:SetTitleJustify("LEFT")
    frame:Hide()

    -- Tab buttons at top (all use secondary color for consistency)
    local btnSettings = PixelUI.CreateButton(frame.content, "Settings", "secondary", 100, 24)
    PixelUI.SetPoint(btnSettings, "TOPLEFT", 10, -10)
    btnSettings:SetOnClick(function()
        addon:SwitchTab("settings")
    end)

    local btnDice = PixelUI.CreateButton(frame.content, "Dice", "secondary", 100, 24)
    PixelUI.SetPoint(btnDice, "TOPLEFT", btnSettings, "TOPRIGHT", 8, 0)
    btnDice:SetOnClick(function()
        addon:SwitchTab("dice")
    end)

    local btnDeathRoll = PixelUI.CreateButton(frame.content, "Death-Roll", "secondary", 100, 24)
    PixelUI.SetPoint(btnDeathRoll, "TOPLEFT", btnDice, "TOPRIGHT", 8, 0)
    btnDeathRoll:SetOnClick(function()
        addon:SwitchTab("deathroll")
    end)

    local btnStats = PixelUI.CreateButton(frame.content, "Statistics", "secondary", 100, 24)
    PixelUI.SetPoint(btnStats, "TOPLEFT", btnDeathRoll, "TOPRIGHT", 8, 0)
    btnStats:SetOnClick(function()
        addon:SwitchTab("statistics")
    end)

    local btnMainAlt = PixelUI.CreateButton(frame.content, "Mains & Alts", "secondary", 120, 24)
    PixelUI.SetPoint(btnMainAlt, "TOPLEFT", btnStats, "TOPRIGHT", 8, 0)
    btnMainAlt:SetOnClick(function()
        addon:SwitchTab("mainalt")
    end)

    local btnExport = PixelUI.CreateButton(frame.content, "Export", "secondary", 80, 24)
    PixelUI.SetPoint(btnExport, "TOPLEFT", btnMainAlt, "TOPRIGHT", 8, 0)
    btnExport:SetOnClick(function()
        addon:SwitchTab("export")
    end)

    -- Content area below buttons
    local content = PixelUI.CreateFrame(frame.content, nil, 730, 460)
    PixelUI.SetPoint(content, "TOPLEFT", btnSettings, "BOTTOMLEFT", 0, -10)

    -- Store references
    frame.tabContent = content
    frame.tabButtons = {
        settings  = btnSettings,
        dice      = btnDice,
        deathroll = btnDeathRoll,
        statistics = btnStats,
        mainalt   = btnMainAlt,
        export    = btnExport,
    }
    addon.content = content
    addon.mainFrame = frame

    -- Toggle visibility function
    function frame:ToggleVisibility()
        if self:IsShown() then
            self:Hide()
        else
            self:Show()
        end
    end

    -- Create tab content
    addon:CreateSettingsTab(content)
    addon:CreateDiceTab(content)
    addon:CreateDeathRollTab(content)
    addon:CreateStatisticsTab(content)
    addon:CreateMainAltTab(content)
    addon:CreateExportTab(content)

    -- Show default tab (Settings)
    addon:SwitchTab("settings")

    addon:Debug("Main frame initialized with PixelUI")

    return frame
end
