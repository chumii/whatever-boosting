--[[
Name: LibSharedMedia-3.0
Revision: $Revision: 114 $
Author: Elkano (elkano@gmx.de)
Inspired By: SurfaceLib by Haste/Otravi (trorat@gmail.com)
Website: http://www.wowace.com/projects/libsharedmedia-3-0/
Description: Shared handling of media data (fonts, sounds, textures, ...) between addons.
Dependencies: LibStub, CallbackHandler-1.0
License: LGPL v2.1
]]

local MAJOR, MINOR = "LibSharedMedia-3.0", 8020003
local lib = LibStub:NewLibrary(MAJOR, MINOR)

if not lib then return end

local _G = getfenv(0)

local pairs     = _G.pairs
local type      = _G.type

local band          = _G.bit.band

local RESTRICTED_FILE_ACCESS = WOW_PROJECT_ID ~= WOW_PROJECT_CLASSIC

lib.callbacks       = lib.callbacks         or LibStub:GetLibrary("CallbackHandler-1.0"):New(lib)
lib.DefaultMedia    = lib.DefaultMedia      or {}
lib.MediaList       = lib.MediaList         or {}
lib.MediaTable      = lib.MediaTable        or {}
lib.MediaType       = lib.MediaType         or {}
lib.OverrideMedia   = lib.OverrideMedia     or {}

local defaultMedia = lib.DefaultMedia
local mediaList = lib.MediaList
local mediaTable = lib.MediaTable
local overrideMedia = lib.OverrideMedia

-- Mediatype constants
lib.MediaType.BACKGROUND    = "background"
lib.MediaType.BORDER        = "border"
lib.MediaType.FONT          = "font"
lib.MediaType.STATUSBAR     = "statusbar"
lib.MediaType.SOUND         = "sound"

-- Populate the brute-force list
local locale = GetLocale()
local function GetFritzQuadrata()
    if locale == "koKR" then
        return "Fonts\\2002.TTF"
    elseif locale == "zhCN" then
        return "Fonts\\ARKai_T.ttf"
    elseif locale == "zhTW" then
        return "Fonts\\blei00d.TTF"
    elseif locale == "ruRU" then
        return "Fonts\\FRIZQT___CYR.TTF"
    else
        return "Fonts\\FRIZQT__.TTF"
    end
end

local function GetArialNarrow()
    if locale == "koKR" then
        return "Fonts\\2002.TTF"
    elseif locale == "zhCN" then
        return "Fonts\\ARKai_T.ttf"
    elseif locale == "zhTW" then
        return "Fonts\\blei00d.TTF"
    elseif locale == "ruRU" then
        return "Fonts\\ARIALN.TTF"
    else
        return "Fonts\\ARIALN.TTF"
    end
end

local function GetSkurri()
    if locale == "koKR" then
        return "Fonts\\2002.TTF"
    elseif locale == "zhCN" then
        return "Fonts\\ARKai_T.ttf"
    elseif locale == "zhTW" then
        return "Fonts\\blei00d.TTF"
    elseif locale == "ruRU" then
        return "Fonts\\SKURRI_CYR.TTF"
    else
        return "Fonts\\SKURRI.TTF"
    end
end

local function GetMorpheus()
    if locale == "koKR" then
        return "Fonts\\2002.TTF"
    elseif locale == "zhCN" then
        return "Fonts\\ARKai_T.ttf"
    elseif locale == "zhTW" then
        return "Fonts\\blei00d.TTF"
    elseif locale == "ruRU" then
        return "Fonts\\MORPHEUS_CYR.TTF"
    else
        return "Fonts\\MORPHEUS.TTF"
    end
end

-- Initialize mediatypes
if not lib.MediaTable.font then lib.MediaTable.font = {} end
if not lib.MediaList.font then lib.MediaList.font = {} end

-- Register default fonts
lib.MediaTable.font["Friz Quadrata TT"] = GetFritzQuadrata()
lib.MediaTable.font["Arial Narrow"] = GetArialNarrow()
lib.MediaTable.font["Skurri"] = GetSkurri()
lib.MediaTable.font["Morpheus"] = GetMorpheus()

-- Rebuild list
local function RebuildFontList()
    local list = {}
    for k in pairs(lib.MediaTable.font) do
        list[#list + 1] = k
    end
    table.sort(list)
    lib.MediaList.font = list
end
RebuildFontList()

function lib:Register(mediatype, key, data, langmask)
    if type(mediatype) ~= "string" then
        error(MAJOR..":Register(mediatype, key, data, langmask) - mediatype must be a string, got "..type(mediatype), 2)
    end
    if type(key) ~= "string" then
        error(MAJOR..":Register(mediatype, key, data, langmask) - key must be a string, got "..type(key), 2)
    end
    mediatype = mediatype:lower()
    if not mediaTable[mediatype] then mediaTable[mediatype] = {} end
    if not mediaList[mediatype] then mediaList[mediatype] = {} end

    if langmask and RESTRICTED_FILE_ACCESS then
        local dominated
        local dominated_locale = band(langmask, lib.locale_bit_koKR) > 0 and "koKR"
                              or band(langmask, lib.locale_bit_zhCN) > 0 and "zhCN"
                              or band(langmask, lib.locale_bit_zhTW) > 0 and "zhTW"
                              or band(langmask, lib.locale_bit_western) > 0 and "western"
        if dominated_locale and dominated_locale ~= (locale == "koKR" and "koKR" or locale == "zhCN" and "zhCN" or locale == "zhTW" and "zhTW" or "western") then
            return false
        end
    end

    mediaTable[mediatype][key] = data

    -- Rebuild list
    local list = {}
    for k in pairs(mediaTable[mediatype]) do
        list[#list + 1] = k
    end
    table.sort(list)
    mediaList[mediatype] = list

    lib.callbacks:Fire("LibSharedMedia_Registered", mediatype, key)
    return true
end

function lib:Fetch(mediatype, key, noDefault)
    if type(mediatype) ~= "string" then
        error(MAJOR..":Fetch(mediatype, key, noDefault) - mediatype must be a string, got "..type(mediatype), 2)
    end
    mediatype = mediatype:lower()
    local mtable = mediaTable[mediatype]
    if not mtable then return nil end

    if overrideMedia[mediatype] then
        key = overrideMedia[mediatype]
    end

    local result = mtable[key]
    if not result and not noDefault then
        result = mtable[defaultMedia[mediatype]]
    end
    return result
end

function lib:IsValid(mediatype, key)
    if type(mediatype) ~= "string" then
        error(MAJOR..":IsValid(mediatype, key) - mediatype must be a string, got "..type(mediatype), 2)
    end
    mediatype = mediatype:lower()
    return mediaTable[mediatype] and mediaTable[mediatype][key] and true or false
end

function lib:HashTable(mediatype)
    if type(mediatype) ~= "string" then
        error(MAJOR..":HashTable(mediatype) - mediatype must be a string, got "..type(mediatype), 2)
    end
    mediatype = mediatype:lower()
    return mediaTable[mediatype]
end

function lib:List(mediatype)
    if type(mediatype) ~= "string" then
        error(MAJOR..":List(mediatype) - mediatype must be a string, got "..type(mediatype), 2)
    end
    mediatype = mediatype:lower()
    return mediaList[mediatype]
end

function lib:GetGlobal(mediatype)
    if type(mediatype) ~= "string" then
        error(MAJOR..":GetGlobal(mediatype) - mediatype must be a string, got "..type(mediatype), 2)
    end
    mediatype = mediatype:lower()
    return overrideMedia[mediatype]
end

function lib:SetGlobal(mediatype, key)
    if type(mediatype) ~= "string" then
        error(MAJOR..":SetGlobal(mediatype, key) - mediatype must be a string, got "..type(mediatype), 2)
    end
    mediatype = mediatype:lower()
    if key and not mediaTable[mediatype][key] then
        return false
    end
    overrideMedia[mediatype] = key
    lib.callbacks:Fire("LibSharedMedia_SetGlobal", mediatype, key)
    return true
end

function lib:GetDefault(mediatype)
    if type(mediatype) ~= "string" then
        error(MAJOR..":GetDefault(mediatype) - mediatype must be a string, got "..type(mediatype), 2)
    end
    mediatype = mediatype:lower()
    return defaultMedia[mediatype]
end

function lib:SetDefault(mediatype, key)
    if type(mediatype) ~= "string" then
        error(MAJOR..":SetDefault(mediatype, key) - mediatype must be a string, got "..type(mediatype), 2)
    end
    mediatype = mediatype:lower()
    if not mediaTable[mediatype] or not mediaTable[mediatype][key] then
        return false
    end
    defaultMedia[mediatype] = key
    return true
end

lib:SetDefault("font", "Friz Quadrata TT")
