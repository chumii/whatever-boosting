--[[
    PixelUI.lua - Reusable Pixel-Perfect UI Library
    Self-contained UI helpers for WoW addons (replaces AbstractFramework dependency)

    Usage: Copy this file to your addon's libs/ folder and load it in your TOC before other UI files.
    Access via: local PixelUI = addon.PixelUI (where addon is your addon namespace)

    Version: 1.0.0
]]
local addonName, addon = ...

local PixelUI = {}
addon.PixelUI = PixelUI

-- Also register globally for cross-addon access if needed
_G.PixelUI = PixelUI

-- ============================================================================
-- Color Palette (matching AbstractFramework's dark pixel theme)
-- ============================================================================

local COLORS = {
    -- Framework colors
    background   = { 0.10, 0.10, 0.10, 0.92 },
    widget       = { 0.15, 0.15, 0.15, 1.0 },
    widget_highlight = { 0.18, 0.18, 0.18, 1.0 },
    header       = { 0.14, 0.14, 0.14, 1.0 },
    black        = { 0.0, 0.0, 0.0, 1.0 },
    border       = { 0.0, 0.0, 0.0, 1.0 },
    border_light = { 0.25, 0.25, 0.25, 1.0 },
    none         = { 0.0, 0.0, 0.0, 0.0 },

    -- List/Table background (slightly lighter than main bg)
    list_bg      = { 0.08, 0.08, 0.08, 1.0 },
    list_alt     = { 0.10, 0.10, 0.10, 1.0 },

    -- Accent color (muted orange)
    accent       = { 0.85, 0.45, 0.15, 1.0 },
    accent_hover = { 0.95, 0.55, 0.25, 1.0 },
    accent_transparent = { 0.85, 0.45, 0.15, 0.4 },

    -- Button colors (muted, professional)
    -- Primary action (confirm, start)
    primary      = { 0.25, 0.55, 0.35, 1.0 },
    primary_hover = { 0.30, 0.65, 0.40, 1.0 },

    -- Secondary/neutral
    secondary    = { 0.30, 0.35, 0.42, 1.0 },
    secondary_hover = { 0.38, 0.43, 0.50, 1.0 },

    -- Warning (yellow-ish)
    warning      = { 0.70, 0.60, 0.25, 1.0 },
    warning_hover = { 0.80, 0.70, 0.30, 1.0 },

    -- Danger (muted red)
    danger       = { 0.60, 0.28, 0.28, 1.0 },
    danger_hover = { 0.70, 0.35, 0.35, 1.0 },

    -- Legacy aliases for backwards compatibility
    green        = { 0.25, 0.55, 0.35, 1.0 },
    green_hover  = { 0.30, 0.65, 0.40, 1.0 },
    red          = { 0.60, 0.28, 0.28, 1.0 },
    red_hover    = { 0.70, 0.35, 0.35, 1.0 },
    yellow       = { 0.70, 0.60, 0.25, 1.0 },
    yellow_hover = { 0.80, 0.70, 0.30, 1.0 },
    static       = { 0.30, 0.35, 0.42, 1.0 },
    static_hover = { 0.38, 0.43, 0.50, 1.0 },

    -- Text colors
    white        = { 1.0, 1.0, 1.0, 1.0 },
    text         = { 0.90, 0.90, 0.90, 1.0 },
    text_dim     = { 0.65, 0.65, 0.65, 1.0 },
    gray         = { 0.55, 0.55, 0.55, 1.0 },
    darkgray     = { 0.40, 0.40, 0.40, 1.0 },
    disabled     = { 0.35, 0.35, 0.35, 1.0 },
    disabled_text = { 0.45, 0.45, 0.45, 1.0 },

    -- Status colors (for text/indicators, not buttons)
    success      = { 0.45, 0.75, 0.45, 1.0 },
    error        = { 0.85, 0.40, 0.40, 1.0 },
    info         = { 0.50, 0.65, 0.85, 1.0 },
}

-- Expose colors for external access
PixelUI.COLORS = COLORS

-- ============================================================================
-- Shared Backdrop (1px pixel borders via WHITE8x8)
-- ============================================================================

local PIXEL_BACKDROP = {
    bgFile   = "Interface\\Buttons\\WHITE8x8",
    edgeFile = "Interface\\Buttons\\WHITE8x8",
    edgeSize = 1,
}

-- ============================================================================
-- Pixel-Snapping
-- ============================================================================

local function PixelSnap(value)
    local scale = UIParent:GetEffectiveScale()
    return math.floor(value * scale + 0.5) / scale
end

-- ============================================================================
-- SetPoint (wrapper with pixel-snapping)
-- ============================================================================

function PixelUI.SetPoint(widget, ...)
    local args = { ... }
    local n = #args

    widget:ClearAllPoints()

    if n == 1 then
        -- SetPoint("CENTER")
        widget:SetPoint(args[1])
    elseif n == 3 and type(args[2]) == "number" then
        -- SetPoint("TOPLEFT", x, y)
        widget:SetPoint(args[1], PixelSnap(args[2]), PixelSnap(args[3]))
    elseif n == 3 and type(args[2]) ~= "number" then
        -- SetPoint("TOPLEFT", relativeTo, "TOPRIGHT")
        widget:SetPoint(args[1], args[2], args[3])
    elseif n == 5 then
        -- SetPoint("TOPLEFT", relativeTo, "TOPRIGHT", x, y)
        widget:SetPoint(args[1], args[2], args[3], PixelSnap(args[4]), PixelSnap(args[5]))
    else
        widget:SetPoint(...)
    end
end

-- ============================================================================
-- AddPoint (like SetPoint but WITHOUT clearing existing points)
-- ============================================================================

function PixelUI.AddPoint(widget, ...)
    local args = { ... }
    local n = #args

    -- No ClearAllPoints() - adds to existing anchors

    if n == 1 then
        widget:SetPoint(args[1])
    elseif n == 3 and type(args[2]) == "number" then
        widget:SetPoint(args[1], PixelSnap(args[2]), PixelSnap(args[3]))
    elseif n == 3 and type(args[2]) ~= "number" then
        widget:SetPoint(args[1], args[2], args[3])
    elseif n == 5 then
        widget:SetPoint(args[1], args[2], args[3], PixelSnap(args[4]), PixelSnap(args[5]))
    else
        widget:SetPoint(...)
    end
end

-- ============================================================================
-- CreateMainFrame (replaces AF.CreateHeaderedFrame)
-- ============================================================================

local HEADER_HEIGHT = 24

function PixelUI.CreateMainFrame(parent, name, title, width, height)
    local frame = CreateFrame("Frame", name, parent, "BackdropTemplate")
    frame:SetSize(width, height)
    frame:SetFrameStrata("HIGH")
    frame:SetToplevel(true)
    frame:SetClampedToScreen(true)

    -- Backdrop: dark background + 1px black border
    frame:SetBackdrop(PIXEL_BACKDROP)
    frame:SetBackdropColor(unpack(COLORS.background))
    frame:SetBackdropBorderColor(unpack(COLORS.black))

    -- Header bar
    local header = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    header:SetHeight(HEADER_HEIGHT)
    header:SetPoint("TOPLEFT", frame, "TOPLEFT", 1, -1)
    header:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -1, -1)
    header:SetBackdrop(PIXEL_BACKDROP)
    header:SetBackdropColor(unpack(COLORS.header))
    header:SetBackdropBorderColor(unpack(COLORS.black))
    frame.header = header

    -- Dragging via header
    header:EnableMouse(true)
    header:RegisterForDrag("LeftButton")
    header:SetScript("OnDragStart", function() frame:StartMoving() end)
    header:SetScript("OnDragStop", function() frame:StopMovingOrSizing() end)
    frame:SetMovable(true)

    -- Title text
    local titleText = header:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    titleText:SetPoint("CENTER", header, "CENTER")
    titleText:SetText(title)
    titleText:SetTextColor(unpack(COLORS.white))
    frame.titleText = titleText

    function frame:SetTitleJustify(justify)
        frame.titleText:ClearAllPoints()
        if justify == "CENTER" then
            frame.titleText:SetPoint("CENTER", frame.header, "CENTER")
        elseif justify == "LEFT" then
            frame.titleText:SetPoint("LEFT", frame.header, "LEFT", 8, 0)
        elseif justify == "RIGHT" then
            frame.titleText:SetPoint("RIGHT", frame.header, "RIGHT", -8, 0)
        end
    end

    -- Close button
    local closeBtn = CreateFrame("Button", nil, header)
    closeBtn:SetSize(16, 16)
    closeBtn:SetPoint("RIGHT", header, "RIGHT", -4, 0)

    local closeText = closeBtn:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    closeText:SetPoint("CENTER")
    closeText:SetText("x")
    closeText:SetTextColor(unpack(COLORS.white))
    closeBtn.label = closeText

    closeBtn:SetScript("OnEnter", function(self)
        self.label:SetTextColor(unpack(COLORS.accent))
    end)
    closeBtn:SetScript("OnLeave", function(self)
        self.label:SetTextColor(unpack(COLORS.white))
    end)
    closeBtn:SetScript("OnClick", function()
        frame:Hide()
    end)

    frame.closeButton = closeBtn

    -- Content area (below header)
    local content = CreateFrame("Frame", nil, frame)
    content:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 0, -1)
    content:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -1, 1)
    frame.content = content

    return frame
end

-- ============================================================================
-- CreateButton (replaces AF.CreateButton)
-- ============================================================================

function PixelUI.CreateButton(parent, text, colorName, width, height)
    local normalColor = COLORS[colorName] or COLORS.accent
    local hoverColor = COLORS[colorName .. "_hover"] or normalColor

    local button = CreateFrame("Button", nil, parent, "BackdropTemplate")
    button:SetSize(width, height)

    button:SetBackdrop(PIXEL_BACKDROP)
    button:SetBackdropColor(normalColor[1], normalColor[2], normalColor[3], normalColor[4])
    button:SetBackdropBorderColor(unpack(COLORS.black))

    -- Store colors for state changes
    button._normalColor = normalColor
    button._hoverColor = hoverColor

    -- Label
    local label = button:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    label:SetPoint("CENTER")
    label:SetText(text)
    label:SetTextColor(unpack(COLORS.white))
    button.label = label

    -- Hover effect
    button:SetScript("OnEnter", function(self)
        if self:IsEnabled() then
            self:SetBackdropColor(self._hoverColor[1], self._hoverColor[2], self._hoverColor[3], self._hoverColor[4])
        end
    end)
    button:SetScript("OnLeave", function(self)
        if self:IsEnabled() then
            self:SetBackdropColor(self._normalColor[1], self._normalColor[2], self._normalColor[3], self._normalColor[4])
        end
    end)

    -- Push-down effect (1px text displacement)
    button:SetScript("OnMouseDown", function(self)
        if self:IsEnabled() then
            self.label:ClearAllPoints()
            self.label:SetPoint("CENTER", 0, -1)
        end
    end)
    button:SetScript("OnMouseUp", function(self)
        self.label:ClearAllPoints()
        self.label:SetPoint("CENTER", 0, 0)
    end)

    -- Click handler
    button._clickHandler = nil
    button:SetScript("OnClick", function(self)
        if self._clickHandler then
            self._clickHandler()
        end
    end)

    function button:SetOnClick(func)
        button._clickHandler = func
    end

    -- Override SetEnabled to update visual state
    local originalSetEnabled = button.SetEnabled
    function button:SetEnabled(enabled)
        if enabled then
            button:Enable()
            button:SetBackdropColor(button._normalColor[1], button._normalColor[2], button._normalColor[3], button._normalColor[4])
            button.label:SetTextColor(unpack(COLORS.white))
        else
            button:Disable()
            button:SetBackdropColor(unpack(COLORS.disabled))
            button.label:SetTextColor(unpack(COLORS.disabled_text))
        end
    end

    -- Override SetText
    function button:SetText(newText)
        button.label:SetText(newText)
    end

    return button
end

-- ============================================================================
-- CreateBorderedFrame (replaces AF.CreateBorderedFrame)
-- ============================================================================

function PixelUI.CreateBorderedFrame(parent, name, width, height)
    local frame = CreateFrame("Frame", name, parent, "BackdropTemplate")
    frame:SetSize(width, height)
    frame:SetBackdrop(PIXEL_BACKDROP)
    frame:SetBackdropColor(unpack(COLORS.widget))
    frame:SetBackdropBorderColor(unpack(COLORS.black))

    return frame
end

-- ============================================================================
-- CreateScrollFrame (replaces AF.CreateScrollFrame)
-- ============================================================================

local SCROLLBAR_WIDTH = 7
local SCROLL_STEP = 20
local MIN_THUMB_HEIGHT = 20

function PixelUI.CreateScrollFrame(parent, name, width, height)
    -- Outer container (same size as requested, acts as the return value)
    local container = CreateFrame("Frame", name, parent)
    container:SetSize(width, height)

    -- Scroll frame (leaves room for scrollbar on right)
    local scrollFrame = CreateFrame("ScrollFrame", name and (name .. "_Scroll") or nil, container)
    scrollFrame:SetPoint("TOPLEFT")
    scrollFrame:SetPoint("BOTTOMRIGHT", -SCROLLBAR_WIDTH, 0)

    -- Scroll child (content container)
    local scrollChild = CreateFrame("Frame", nil, scrollFrame)
    scrollChild:SetWidth(width - SCROLLBAR_WIDTH)
    scrollChild:SetHeight(1)
    scrollFrame:SetScrollChild(scrollChild)
    container.scrollContent = scrollChild

    -- Scrollbar track
    local track = CreateFrame("Frame", nil, container, "BackdropTemplate")
    track:SetWidth(SCROLLBAR_WIDTH)
    track:SetPoint("TOPRIGHT", container, "TOPRIGHT", 0, 0)
    track:SetPoint("BOTTOMRIGHT", container, "BOTTOMRIGHT", 0, 0)
    track:SetBackdrop(PIXEL_BACKDROP)
    track:SetBackdropColor(0.08, 0.08, 0.08, 0.8)
    track:SetBackdropBorderColor(0, 0, 0, 0)

    -- Scrollbar thumb
    local thumb = CreateFrame("Button", nil, track, "BackdropTemplate")
    thumb:SetWidth(SCROLLBAR_WIDTH)
    thumb:SetHeight(MIN_THUMB_HEIGHT)
    thumb:SetPoint("TOP", track, "TOP", 0, 0)
    thumb:SetBackdrop(PIXEL_BACKDROP)
    thumb:SetBackdropColor(unpack(COLORS.accent))
    thumb:SetBackdropBorderColor(0, 0, 0, 0)
    thumb:EnableMouse(true)

    -- Hover effect on thumb
    thumb:SetScript("OnEnter", function(self)
        self:SetBackdropColor(unpack(COLORS.accent_hover))
    end)
    thumb:SetScript("OnLeave", function(self)
        if not self.dragging then
            self:SetBackdropColor(unpack(COLORS.accent))
        end
    end)

    -- Update thumb position and size based on scroll state
    local function UpdateThumb()
        local contentHeight = scrollChild:GetHeight()
        local viewHeight = scrollFrame:GetHeight()

        if contentHeight <= viewHeight then
            thumb:Hide()
            return
        end

        thumb:Show()

        -- Thumb height proportional to visible ratio
        local ratio = viewHeight / contentHeight
        local trackHeight = track:GetHeight()
        local thumbHeight = math.max(MIN_THUMB_HEIGHT, trackHeight * ratio)
        thumb:SetHeight(thumbHeight)

        -- Thumb position based on scroll offset
        local maxScroll = contentHeight - viewHeight
        local currentScroll = scrollFrame:GetVerticalScroll()
        local scrollRatio = currentScroll / maxScroll
        local maxThumbOffset = trackHeight - thumbHeight

        thumb:ClearAllPoints()
        thumb:SetPoint("TOP", track, "TOP", 0, -(maxThumbOffset * scrollRatio))
    end

    -- Mouse wheel scrolling
    container:EnableMouseWheel(true)
    container:SetScript("OnMouseWheel", function(self, delta)
        local contentHeight = scrollChild:GetHeight()
        local viewHeight = scrollFrame:GetHeight()
        local maxScroll = math.max(0, contentHeight - viewHeight)
        local current = scrollFrame:GetVerticalScroll()
        local newScroll = math.max(0, math.min(maxScroll, current - (delta * SCROLL_STEP)))
        scrollFrame:SetVerticalScroll(newScroll)
        UpdateThumb()
    end)

    -- Thumb dragging
    thumb:RegisterForDrag("LeftButton")
    thumb:SetScript("OnDragStart", function(self)
        self.dragging = true
        self.dragStartY = select(2, GetCursorPosition()) / UIParent:GetEffectiveScale()
        self.dragStartScroll = scrollFrame:GetVerticalScroll()
    end)
    thumb:SetScript("OnDragStop", function(self)
        self.dragging = false
        self:SetBackdropColor(unpack(COLORS.accent))
    end)
    thumb:SetScript("OnUpdate", function(self)
        if not self.dragging then return end

        local cursorY = select(2, GetCursorPosition()) / UIParent:GetEffectiveScale()
        local deltaY = self.dragStartY - cursorY

        local contentHeight = scrollChild:GetHeight()
        local viewHeight = scrollFrame:GetHeight()
        local trackHeight = track:GetHeight()
        local thumbHeight = self:GetHeight()
        local maxThumbTravel = trackHeight - thumbHeight

        if maxThumbTravel <= 0 then return end

        local maxScroll = contentHeight - viewHeight
        local scrollDelta = (deltaY / maxThumbTravel) * maxScroll
        local newScroll = math.max(0, math.min(maxScroll, self.dragStartScroll + scrollDelta))

        scrollFrame:SetVerticalScroll(newScroll)
        UpdateThumb()
    end)

    -- Store reference for external updates
    container._updateThumb = UpdateThumb
    container.scrollFrame = scrollFrame

    -- Hook into scrollChild height changes to update thumb
    hooksecurefunc(scrollChild, "SetHeight", function()
        C_Timer.After(0, UpdateThumb)
    end)

    return container
end

-- ============================================================================
-- CreateText (replaces AF.CreateFontString)
-- ============================================================================

function PixelUI.CreateText(parent, text, colorName)
    local fontString = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    fontString:SetText(text)
    if colorName and COLORS[colorName] then
        fontString:SetTextColor(unpack(COLORS[colorName]))
    end
    return fontString
end

-- ============================================================================
-- SetSize (wrapper with pixel-snapping)
-- ============================================================================

function PixelUI.SetSize(widget, width, height)
    widget:SetSize(PixelSnap(width), PixelSnap(height))
end

-- ============================================================================
-- GetColorRGB / GetColorTable (color accessors)
-- ============================================================================

function PixelUI.GetColorRGB(colorName)
    local c = COLORS[colorName]
    if c then
        return c[1], c[2], c[3]
    end
    return 1, 1, 1
end

function PixelUI.GetColorTable(colorName)
    return COLORS[colorName] or COLORS.white
end

-- ============================================================================
-- CreateFrame (simple container without backdrop)
-- ============================================================================

function PixelUI.CreateFrame(parent, name, width, height)
    local frame = CreateFrame("Frame", name, parent)
    frame:SetSize(width or 1, height or 1)
    return frame
end

-- ============================================================================
-- CreateTexture (colored rectangle/separator)
-- ============================================================================

function PixelUI.CreateTexture(parent, name, color)
    local texture = parent:CreateTexture(name, "ARTWORK")
    texture:SetTexture("Interface\\Buttons\\WHITE8x8")

    -- color can be string (from COLORS) or {r,g,b,a} table
    if type(color) == "string" and COLORS[color] then
        texture:SetVertexColor(unpack(COLORS[color]))
    elseif type(color) == "table" then
        texture:SetVertexColor(unpack(color))
    else
        texture:SetVertexColor(1, 1, 1, 1)
    end

    -- Add SetColor method
    function texture:SetColor(newColor)
        if type(newColor) == "string" and COLORS[newColor] then
            texture:SetVertexColor(unpack(COLORS[newColor]))
        elseif type(newColor) == "table" then
            texture:SetVertexColor(unpack(newColor))
        end
    end

    return texture
end

-- ============================================================================
-- CreateEditBox (text/number input)
-- ============================================================================

function PixelUI.CreateEditBox(parent, label, width, height, mode)
    -- mode: nil (text), "number", "multiline"
    local container = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    container:SetSize(width, height or 24)
    container:SetBackdrop(PIXEL_BACKDROP)
    container:SetBackdropColor(unpack(COLORS.widget))
    container:SetBackdropBorderColor(unpack(COLORS.black))

    local editBox
    if mode == "multiline" then
        -- Multiline uses ScrollFrame + EditBox
        local scrollFrame = CreateFrame("ScrollFrame", nil, container)
        scrollFrame:SetPoint("TOPLEFT", 4, -4)
        scrollFrame:SetPoint("BOTTOMRIGHT", -4, 4)

        editBox = CreateFrame("EditBox", nil, scrollFrame)
        editBox:SetMultiLine(true)
        editBox:SetAutoFocus(false)
        editBox:SetWidth(width - 12)
        editBox:SetFontObject("GameFontHighlightSmall")
        editBox:SetTextColor(unpack(COLORS.white))
        scrollFrame:SetScrollChild(editBox)

        container.scrollFrame = scrollFrame
    else
        editBox = CreateFrame("EditBox", nil, container)
        editBox:SetPoint("TOPLEFT", 6, 0)
        editBox:SetPoint("BOTTOMRIGHT", -6, 0)
        editBox:SetAutoFocus(false)
        editBox:SetFontObject("GameFontHighlightSmall")
        editBox:SetTextColor(unpack(COLORS.white))

        if mode == "number" then
            editBox:SetNumeric(true)
        end
    end

    container.editBox = editBox

    -- Placeholder label (disappears when text entered)
    local placeholder = editBox:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    placeholder:SetPoint("LEFT", editBox, "LEFT", 0, 0)
    placeholder:SetText(label or "")
    placeholder:SetTextColor(unpack(COLORS.gray))
    container.placeholder = placeholder

    -- Show/hide placeholder based on text
    local function UpdatePlaceholder()
        if editBox:GetText() == "" then
            placeholder:Show()
        else
            placeholder:Hide()
        end
    end

    editBox:SetScript("OnTextChanged", function(self)
        UpdatePlaceholder()
        if container._onTextChanged then
            container._onTextChanged(self:GetText())
        end
    end)

    editBox:SetScript("OnEditFocusGained", function()
        container:SetBackdropBorderColor(unpack(COLORS.accent))
    end)

    editBox:SetScript("OnEditFocusLost", function()
        container:SetBackdropBorderColor(unpack(COLORS.black))
    end)

    editBox:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)

    editBox:SetScript("OnEnterPressed", function(self)
        if mode ~= "multiline" then
            self:ClearFocus()
        end
    end)

    -- Hover highlight
    container:SetScript("OnEnter", function(self)
        if not editBox:HasFocus() then
            self:SetBackdropColor(unpack(COLORS.widget_highlight))
        end
    end)
    container:SetScript("OnLeave", function(self)
        self:SetBackdropColor(unpack(COLORS.widget))
    end)

    -- Click to focus
    container:EnableMouse(true)
    container:SetScript("OnMouseDown", function()
        editBox:SetFocus()
    end)

    -- Public methods
    function container:SetOnTextChanged(func)
        container._onTextChanged = func
    end

    function container:GetValue()
        local text = editBox:GetText()
        if mode == "number" then
            return tonumber(text) or 0
        end
        return text
    end

    function container:SetText(text)
        editBox:SetText(text or "")
        UpdatePlaceholder()
    end

    function container:GetText()
        return editBox:GetText()
    end

    function container:SetPlaceholder(text)
        placeholder:SetText(text or "")
    end

    function container:SetEnabled(enabled)
        if enabled then
            editBox:Enable()
            container:SetBackdropColor(unpack(COLORS.widget))
            editBox:SetTextColor(unpack(COLORS.white))
        else
            editBox:Disable()
            container:SetBackdropColor(unpack(COLORS.disabled))
            editBox:SetTextColor(unpack(COLORS.disabled_text))
        end
    end

    return container
end

-- ============================================================================
-- CreateCheckButton (checkbox with label)
-- ============================================================================

function PixelUI.CreateCheckButton(parent, label, onCheck)
    local container = CreateFrame("Button", nil, parent)
    container:SetHeight(20)

    -- Checkbox box (14x14)
    local box = CreateFrame("Frame", nil, container, "BackdropTemplate")
    box:SetSize(14, 14)
    box:SetPoint("LEFT", 0, 0)
    box:SetBackdrop(PIXEL_BACKDROP)
    box:SetBackdropColor(unpack(COLORS.widget))
    box:SetBackdropBorderColor(unpack(COLORS.black))
    container.box = box

    -- Check mark (accent-colored inner square)
    local checkMark = box:CreateTexture(nil, "OVERLAY")
    checkMark:SetTexture("Interface\\Buttons\\WHITE8x8")
    checkMark:SetPoint("TOPLEFT", 3, -3)
    checkMark:SetPoint("BOTTOMRIGHT", -3, 3)
    checkMark:SetVertexColor(unpack(COLORS.accent))
    checkMark:Hide()
    container.checkMark = checkMark

    -- Label text
    local labelText = container:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    labelText:SetPoint("LEFT", box, "RIGHT", 6, 0)
    labelText:SetText(label or "")
    labelText:SetTextColor(unpack(COLORS.white))
    container.label = labelText

    -- Adjust container width based on label
    container:SetWidth(14 + 6 + labelText:GetStringWidth() + 4)

    -- State
    container._checked = false
    container._onCheck = onCheck

    -- Click handler
    container:SetScript("OnClick", function(self)
        self._checked = not self._checked
        if self._checked then
            checkMark:Show()
        else
            checkMark:Hide()
        end
        if self._onCheck then
            self._onCheck(self._checked)
        end
    end)

    -- Hover effect
    container:SetScript("OnEnter", function()
        box:SetBackdropColor(unpack(COLORS.widget_highlight))
    end)
    container:SetScript("OnLeave", function()
        box:SetBackdropColor(unpack(COLORS.widget))
    end)

    -- Public methods
    function container:SetChecked(checked)
        container._checked = checked
        if checked then
            checkMark:Show()
        else
            checkMark:Hide()
        end
    end

    function container:GetChecked()
        return container._checked
    end

    function container:SetText(text)
        labelText:SetText(text or "")
        container:SetWidth(14 + 6 + labelText:GetStringWidth() + 4)
    end

    function container:SetEnabled(enabled)
        if enabled then
            container:Enable()
            labelText:SetTextColor(unpack(COLORS.white))
            box:SetBackdropColor(unpack(COLORS.widget))
        else
            container:Disable()
            labelText:SetTextColor(unpack(COLORS.disabled_text))
            box:SetBackdropColor(unpack(COLORS.disabled))
        end
    end

    function container:SetOnCheck(func)
        container._onCheck = func
    end

    return container
end

-- ============================================================================
-- CreateDropdown (select menu)
-- ============================================================================

local DROPDOWN_HEIGHT = 24
local DROPDOWN_ITEM_HEIGHT = 20

function PixelUI.CreateDropdown(parent, width, maxSlots)
    maxSlots = maxSlots or 8

    local container = CreateFrame("Frame", nil, parent)
    container:SetSize(width, DROPDOWN_HEIGHT)

    -- Main button
    local button = CreateFrame("Button", nil, container, "BackdropTemplate")
    button:SetAllPoints()
    button:SetBackdrop(PIXEL_BACKDROP)
    button:SetBackdropColor(unpack(COLORS.widget))
    button:SetBackdropBorderColor(unpack(COLORS.black))

    -- Selected text
    local selectedText = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    selectedText:SetPoint("LEFT", 8, 0)
    selectedText:SetPoint("RIGHT", -20, 0)
    selectedText:SetJustifyH("LEFT")
    selectedText:SetTextColor(unpack(COLORS.white))
    container.selectedText = selectedText

    -- Arrow indicator (using WoW texture instead of Unicode)
    local arrow = button:CreateTexture(nil, "OVERLAY")
    arrow:SetSize(12, 12)
    arrow:SetPoint("RIGHT", -6, 0)
    arrow:SetTexture("Interface\\Buttons\\UI-ScrollBar-ScrollDownButton-Up")
    arrow:SetTexCoord(0.25, 0.75, 0.25, 0.75)  -- Crop to just the arrow
    arrow:SetVertexColor(unpack(COLORS.gray))
    container.arrow = arrow

    -- Dropdown popup (hidden by default)
    local popup = CreateFrame("Frame", nil, button, "BackdropTemplate")
    popup:SetPoint("TOPLEFT", button, "BOTTOMLEFT", 0, -1)
    popup:SetWidth(width)
    popup:SetBackdrop(PIXEL_BACKDROP)
    popup:SetBackdropColor(unpack(COLORS.background))
    popup:SetBackdropBorderColor(unpack(COLORS.black))
    popup:SetFrameStrata("DIALOG")
    popup:Hide()
    container.popup = popup

    -- Scroll frame for items (if more than maxSlots)
    local scrollFrame = CreateFrame("ScrollFrame", nil, popup)
    scrollFrame:SetPoint("TOPLEFT", 1, -1)
    scrollFrame:SetPoint("BOTTOMRIGHT", -1, 1)
    popup.scrollFrame = scrollFrame

    local scrollChild = CreateFrame("Frame", nil, scrollFrame)
    scrollChild:SetWidth(width - 2)
    scrollFrame:SetScrollChild(scrollChild)
    popup.scrollChild = scrollChild

    -- Item buttons pool
    container._itemButtons = {}
    container._items = {}
    container._selected = nil
    container._onSelect = nil

    local function CreateItemButton(index)
        local itemBtn = CreateFrame("Button", nil, scrollChild, "BackdropTemplate")
        itemBtn:SetSize(width - 2, DROPDOWN_ITEM_HEIGHT)
        itemBtn:SetPoint("TOPLEFT", 0, -(index - 1) * DROPDOWN_ITEM_HEIGHT)
        itemBtn:SetBackdrop(PIXEL_BACKDROP)
        itemBtn:SetBackdropColor(0, 0, 0, 0)
        itemBtn:SetBackdropBorderColor(0, 0, 0, 0)

        local itemText = itemBtn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        itemText:SetPoint("LEFT", 8, 0)
        itemText:SetPoint("RIGHT", -8, 0)
        itemText:SetJustifyH("LEFT")
        itemText:SetTextColor(unpack(COLORS.white))
        itemBtn.label = itemText

        itemBtn:SetScript("OnEnter", function(self)
            if not self._disabled then
                self:SetBackdropColor(unpack(COLORS.accent_transparent))
            end
        end)
        itemBtn:SetScript("OnLeave", function(self)
            self:SetBackdropColor(0, 0, 0, 0)
        end)

        itemBtn:SetScript("OnClick", function(self)
            if self._disabled then return end

            container._selected = self._value
            selectedText:SetText(self._text)
            popup:Hide()

            if self._callback then
                self._callback()
            end
            if container._onSelect then
                container._onSelect(self._value, self._text)
            end
        end)

        return itemBtn
    end

    local function RefreshItems()
        local items = container._items
        local numItems = #items

        -- Show/hide items
        for i, item in ipairs(items) do
            local itemBtn = container._itemButtons[i]
            if not itemBtn then
                itemBtn = CreateItemButton(i)
                container._itemButtons[i] = itemBtn
            end

            itemBtn._text = item.text
            itemBtn._value = item.value
            itemBtn._disabled = item.disabled
            itemBtn._callback = item.callback
            itemBtn.label:SetText(item.text)

            if item.disabled then
                itemBtn.label:SetTextColor(unpack(COLORS.disabled_text))
            else
                itemBtn.label:SetTextColor(unpack(COLORS.white))
            end

            itemBtn:Show()
        end

        -- Hide excess buttons
        for i = numItems + 1, #container._itemButtons do
            container._itemButtons[i]:Hide()
        end

        -- Update popup height
        local visibleItems = math.min(numItems, maxSlots)
        popup:SetHeight(visibleItems * DROPDOWN_ITEM_HEIGHT + 2)
        scrollChild:SetHeight(numItems * DROPDOWN_ITEM_HEIGHT)

        -- Enable scrolling if needed
        if numItems > maxSlots then
            popup:EnableMouseWheel(true)
            popup:SetScript("OnMouseWheel", function(self, delta)
                local current = scrollFrame:GetVerticalScroll()
                local maxScroll = (numItems - maxSlots) * DROPDOWN_ITEM_HEIGHT
                local newScroll = math.max(0, math.min(maxScroll, current - delta * DROPDOWN_ITEM_HEIGHT))
                scrollFrame:SetVerticalScroll(newScroll)
            end)
        else
            popup:EnableMouseWheel(false)
            popup:SetScript("OnMouseWheel", nil)
        end
    end

    -- Toggle popup
    button:SetScript("OnClick", function()
        if popup:IsShown() then
            popup:Hide()
        else
            RefreshItems()
            popup:Show()
        end
    end)

    -- Hover effect
    button:SetScript("OnEnter", function(self)
        self:SetBackdropColor(unpack(COLORS.widget_highlight))
    end)
    button:SetScript("OnLeave", function(self)
        self:SetBackdropColor(unpack(COLORS.widget))
    end)

    -- Close popup when clicking elsewhere
    popup:SetScript("OnShow", function()
        popup:SetFrameLevel(button:GetFrameLevel() + 10)
    end)

    -- Public methods
    function container:SetItems(items)
        -- items: {{text = "...", value = ..., [disabled], [callback]}, ...}
        container._items = items
        if popup:IsShown() then
            RefreshItems()
        end
    end

    function container:SetSelected(value)
        container._selected = value
        for _, item in ipairs(container._items) do
            if item.value == value then
                selectedText:SetText(item.text)
                return
            end
        end
        selectedText:SetText("")
    end

    function container:GetSelected()
        return container._selected
    end

    function container:SetOnSelect(func)
        container._onSelect = func
    end

    function container:SetEnabled(enabled)
        if enabled then
            button:Enable()
            selectedText:SetTextColor(unpack(COLORS.white))
            button:SetBackdropColor(unpack(COLORS.widget))
        else
            button:Disable()
            selectedText:SetTextColor(unpack(COLORS.disabled_text))
            button:SetBackdropColor(unpack(COLORS.disabled))
            popup:Hide()
        end
    end

    function container:ClosePopup()
        popup:Hide()
    end

    return container
end

-- ============================================================================
-- CreateSlider (horizontal slider with value input)
-- ============================================================================

local SLIDER_HEIGHT = 8
local THUMB_WIDTH = 12

function PixelUI.CreateSlider(parent, label, width, low, high, step, isPercentage)
    low = low or 0
    high = high or 100
    step = step or 1

    local container = CreateFrame("Frame", nil, parent)
    container:SetSize(width, 40)

    -- Label
    local labelText = container:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    labelText:SetPoint("TOPLEFT", 0, 0)
    labelText:SetText(label or "")
    labelText:SetTextColor(unpack(COLORS.white))
    container.label = labelText

    -- Track
    local track = CreateFrame("Frame", nil, container, "BackdropTemplate")
    track:SetHeight(SLIDER_HEIGHT)
    track:SetPoint("TOPLEFT", 0, -16)
    track:SetPoint("TOPRIGHT", -50, -16)
    track:SetBackdrop(PIXEL_BACKDROP)
    track:SetBackdropColor(unpack(COLORS.widget))
    track:SetBackdropBorderColor(unpack(COLORS.black))

    -- Fill (shows current value)
    local fill = track:CreateTexture(nil, "OVERLAY")
    fill:SetTexture("Interface\\Buttons\\WHITE8x8")
    fill:SetPoint("TOPLEFT", 1, -1)
    fill:SetHeight(SLIDER_HEIGHT - 2)
    fill:SetVertexColor(unpack(COLORS.accent))

    -- Thumb
    local thumb = CreateFrame("Button", nil, track, "BackdropTemplate")
    thumb:SetSize(THUMB_WIDTH, SLIDER_HEIGHT + 4)
    thumb:SetBackdrop(PIXEL_BACKDROP)
    thumb:SetBackdropColor(unpack(COLORS.accent))
    thumb:SetBackdropBorderColor(unpack(COLORS.black))
    thumb:EnableMouse(true)

    -- Value editbox
    local valueBox = PixelUI.CreateEditBox(container, nil, 45, 20, "number")
    valueBox:SetPoint("LEFT", track, "RIGHT", 5, 0)

    -- State
    container._value = low
    container._min = low
    container._max = high
    container._step = step
    container._isPercentage = isPercentage
    container._onValueChanged = nil

    local function ClampValue(value)
        value = math.max(container._min, math.min(container._max, value))
        -- Snap to step
        value = math.floor(value / container._step + 0.5) * container._step
        return value
    end

    local function UpdateVisual()
        local range = container._max - container._min
        if range <= 0 then range = 1 end
        local ratio = (container._value - container._min) / range
        local trackWidth = track:GetWidth() - 2

        fill:SetWidth(math.max(1, trackWidth * ratio))

        thumb:ClearAllPoints()
        thumb:SetPoint("CENTER", track, "LEFT", 1 + trackWidth * ratio, 0)

        local displayValue = container._value
        if isPercentage then
            valueBox:SetText(string.format("%.0f%%", displayValue))
        else
            if step < 1 then
                valueBox:SetText(string.format("%.1f", displayValue))
            else
                valueBox:SetText(string.format("%.0f", displayValue))
            end
        end
    end

    local function SetValue(value, silent)
        value = ClampValue(value)
        if value ~= container._value then
            container._value = value
            UpdateVisual()
            if not silent and container._onValueChanged then
                container._onValueChanged(value)
            end
        end
    end

    -- Thumb dragging
    thumb:RegisterForDrag("LeftButton")
    thumb:SetScript("OnDragStart", function(self)
        self.dragging = true
    end)
    thumb:SetScript("OnDragStop", function(self)
        self.dragging = false
    end)
    thumb:SetScript("OnUpdate", function(self)
        if not self.dragging then return end

        local cursorX = GetCursorPosition() / UIParent:GetEffectiveScale()
        local trackLeft = track:GetLeft()
        local trackWidth = track:GetWidth() - 2

        local ratio = (cursorX - trackLeft - 1) / trackWidth
        ratio = math.max(0, math.min(1, ratio))

        local value = container._min + ratio * (container._max - container._min)
        SetValue(value)
    end)

    -- Click on track to set value
    track:EnableMouse(true)
    track:SetScript("OnMouseDown", function(self)
        local cursorX = GetCursorPosition() / UIParent:GetEffectiveScale()
        local trackLeft = track:GetLeft()
        local trackWidth = track:GetWidth() - 2

        local ratio = (cursorX - trackLeft - 1) / trackWidth
        ratio = math.max(0, math.min(1, ratio))

        local value = container._min + ratio * (container._max - container._min)
        SetValue(value)
    end)

    -- Value box input
    valueBox:SetOnTextChanged(function(text)
        -- Remove percentage sign if present
        text = text:gsub("%%", "")
        local num = tonumber(text)
        if num then
            SetValue(num)
        end
    end)

    -- Hover effects
    thumb:SetScript("OnEnter", function(self)
        self:SetBackdropColor(unpack(COLORS.accent_hover))
    end)
    thumb:SetScript("OnLeave", function(self)
        if not self.dragging then
            self:SetBackdropColor(unpack(COLORS.accent))
        end
    end)

    -- Initialize
    C_Timer.After(0, UpdateVisual)

    -- Public methods
    function container:SetValue(value)
        SetValue(value, false)
    end

    function container:GetValue()
        return container._value
    end

    function container:SetMinMaxValues(min, max)
        container._min = min
        container._max = max
        container._value = ClampValue(container._value)
        UpdateVisual()
    end

    function container:SetOnValueChanged(func)
        container._onValueChanged = func
    end

    function container:SetEnabled(enabled)
        if enabled then
            thumb:Enable()
            track:EnableMouse(true)
            valueBox:SetEnabled(true)
            labelText:SetTextColor(unpack(COLORS.white))
        else
            thumb:Disable()
            track:EnableMouse(false)
            valueBox:SetEnabled(false)
            labelText:SetTextColor(unpack(COLORS.disabled_text))
        end
    end

    return container
end

-- ============================================================================
-- AnimatedResize (smooth frame resizing)
-- ============================================================================

function PixelUI.AnimatedResize(frame, targetWidth, targetHeight, duration)
    duration = duration or 0.2

    local startWidth = frame:GetWidth()
    local startHeight = frame:GetHeight()
    local startTime = GetTime()

    frame._resizeAnimation = true

    local function OnUpdate()
        if not frame._resizeAnimation then return end

        local elapsed = GetTime() - startTime
        local progress = math.min(1, elapsed / duration)

        -- Ease out quad
        progress = 1 - (1 - progress) * (1 - progress)

        local currentWidth = startWidth + (targetWidth - startWidth) * progress
        local currentHeight = startHeight + (targetHeight - startHeight) * progress

        frame:SetSize(PixelSnap(currentWidth), PixelSnap(currentHeight))

        if progress >= 1 then
            frame._resizeAnimation = false
            frame:SetScript("OnUpdate", nil)
        end
    end

    frame:SetScript("OnUpdate", OnUpdate)
end

-- ============================================================================
-- Font Constants (for compatibility)
-- ============================================================================

PixelUI.FONT_TITLE = "GameFontNormalLarge"
PixelUI.FONT_NORMAL = "GameFontNormal"
PixelUI.FONT_SMALL = "GameFontNormalSmall"
PixelUI.FONT_HIGHLIGHT = "GameFontHighlight"
PixelUI.FONT_HIGHLIGHT_SMALL = "GameFontHighlightSmall"
