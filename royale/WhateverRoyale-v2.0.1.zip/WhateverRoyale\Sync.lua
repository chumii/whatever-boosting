--[[
    WhateverRoyale - Sync.lua
    Peer-to-peer session sync over WoW addon messages.

    Protocol (all via addon:SendAddonMessage / HandleAddonMessage, prefix "WR"):
      WRSYNC_DIGEST  sid1,sid2,...               Announce my hosted complete/abandoned sessions
      WRSYNC_REQ     sessionId                   Request a specific session from its host
      WRSYNC_BEGIN   tId|sessionId|totalChunks|1 Start of chunked transfer
      WRSYNC_DATA    tId|index|chunk             One data chunk (index 1-based)
      WRSYNC_END     tId                         Transfer complete — reassemble and merge

    Encoding: LibSerialize → LibDeflate:CompressDeflate → LibDeflate:EncodeForWoWAddonChannel
    Payload:  reuses addon:BuildExportPayload({sessionId}) from Export.lua

    Merge rules (on receive):
    - Self-messages ignored (sender == own character)
    - Host-verified: sender must equal session.hostCharacter (normalized to Name-Realm)
    - Immutable: existing sessionId is never overwritten (first-write-wins)
    - Characters: slim unlinked records created for unknown chars; existing linkage preserved
    - After any insert: addon:RebuildAllCharacterStats() called once (debounced 1 s)

    Reach:   group/raid channel only (PARTY / RAID / INSTANCE_CHAT)
    Trigger: on session close + on GROUP_ROSTER_UPDATE (login/group join, debounced 10 s)
    Setting: WhateverRoyaleDB.settings.autoShareSessions (default true)
]]

local addonName, addon = ...

-- ============================================================================
-- Constants
-- ============================================================================

local SYNC_PROTO   = 1      -- protocol version embedded in WRSYNC_BEGIN
local CHUNK_SIZE   = 200    -- bytes per WRSYNC_DATA chunk (well under 255 byte limit)
local MAX_CHUNKS   = 400    -- upper safety limit; larger sessions are skipped
local SEND_INTERVAL  = 0.25 -- seconds between queued sends
local DIGEST_DEBOUNCE = 10  -- seconds to debounce GROUP_ROSTER_UPDATE digest sends
local TRANSFER_TIMEOUT = 30 -- seconds before an incomplete incoming transfer is dropped

-- ============================================================================
-- Library helpers
-- ============================================================================

local function GetSyncLibs()
    local ld = LibStub and LibStub("LibDeflate",   true)
    local ls = LibStub and LibStub("LibSerialize", true)
    return ld, ls
end

local function SyncEncode(payload)
    local ld, ls = GetSyncLibs()
    if not ld or not ls then return nil end
    local serialized = ls:Serialize(payload)
    if not serialized then return nil end
    local compressed = ld:CompressDeflate(serialized, {level = 9})
    if not compressed then return nil end
    return ld:EncodeForWoWAddonChannel(compressed)
end

local function SyncDecode(encoded)
    local ld, ls = GetSyncLibs()
    if not ld or not ls then return nil end
    local compressed = ld:DecodeForWoWAddonChannel(encoded)
    if not compressed then return nil end
    local decompressed = ld:DecompressDeflate(compressed)
    if not decompressed then return nil end
    local ok, data = ls:Deserialize(decompressed)
    if not ok then return nil end
    return data
end

-- ============================================================================
-- Sender normalization
-- ============================================================================

local function NormalizeSender(sender)
    -- Addon-message sender can be "Name" (same realm) or "Name-Realm"
    if not sender:find("-") then
        return sender .. "-" .. GetRealmName()
    end
    return sender
end

-- ============================================================================
-- Channel helper
-- ============================================================================

function addon:GetGroupChannel()
    if IsInGroup(LE_PARTY_CATEGORY_INSTANCE) then
        return "INSTANCE_CHAT"
    elseif IsInRaid() then
        return "RAID"
    elseif IsInGroup() then
        return "PARTY"
    end
    return nil
end

-- ============================================================================
-- Send queue (paced to avoid addon-message throttle)
-- ============================================================================

local sendQueue  = {}  -- {msgType, data, channel}
local sendTicker = nil

local function FlushQueue()
    if #sendQueue == 0 then
        if sendTicker then
            sendTicker:Cancel()
            sendTicker = nil
        end
        return
    end
    local item = table.remove(sendQueue, 1)
    addon:SendAddonMessage(item[1], item[2], item[3])
end

local function EnqueueMessage(msgType, data, channel)
    table.insert(sendQueue, {msgType, data, channel})
    if not sendTicker then
        sendTicker = C_Timer.NewTicker(SEND_INTERVAL, FlushQueue)
    end
end

-- ============================================================================
-- Transfer ID generator
-- ============================================================================

local transferCounter = 0
local function NewTransferId()
    transferCounter = transferCounter + 1
    -- Use GetTime() millis % 1M to keep it short; counter disambiguates same-ms
    return string.format("%d_%d", math.floor(GetTime() * 1000) % 1000000, transferCounter)
end

-- ============================================================================
-- Outbound transfer (encode → chunk → queue)
-- ============================================================================

local function BuildOwnedSessionIds()
    local myId = addon:GetCurrentCharacterId()
    local ids = {}
    if WhateverRoyaleDB.sessions then
        for sid, session in pairs(WhateverRoyaleDB.sessions) do
            if session.hostCharacter == myId and
               (session.status == "completed" or session.status == "abandoned") then
                ids[#ids + 1] = sid
            end
        end
    end
    return ids
end

local function SendTransfer(sessionId, channel)
    local payload = addon:BuildExportPayload({sessionId})
    if not payload then return end

    local encoded = SyncEncode(payload)
    if not encoded then
        addon:Debug("[Sync] Encoding failed for session " .. sessionId)
        return
    end

    -- Split into chunks
    local chunks = {}
    local pos = 1
    while pos <= #encoded do
        chunks[#chunks + 1] = encoded:sub(pos, pos + CHUNK_SIZE - 1)
        pos = pos + CHUNK_SIZE
    end

    if #chunks > MAX_CHUNKS then
        addon:Debug(string.format("[Sync] Session %s zu gross (%d Chunks), wird uebersprungen",
            sessionId, #chunks))
        return
    end

    local tId = NewTransferId()

    -- WRSYNC_BEGIN
    EnqueueMessage("WRSYNC_BEGIN",
        string.format("%s|%s|%d|%d", tId, sessionId, #chunks, SYNC_PROTO),
        channel)

    -- WRSYNC_DATA chunks (1-based index)
    for idx, chunk in ipairs(chunks) do
        EnqueueMessage("WRSYNC_DATA",
            string.format("%s|%d|%s", tId, idx, chunk),
            channel)
    end

    -- WRSYNC_END
    EnqueueMessage("WRSYNC_END", tId, channel)

    addon:Debug(string.format("[Sync] Transfer von Session %s in Queue (%d Chunks) auf %s",
        sessionId, #chunks, channel))
end

-- ============================================================================
-- Public: share a session on session close
-- ============================================================================

function addon:AutoShareSession(sessionId)
    if not WhateverRoyaleDB.settings.autoShareSessions then return end
    local channel = self:GetGroupChannel()
    if not channel then return end

    local session = self:GetSession(sessionId)
    if not session then return end
    if session.status ~= "completed" and session.status ~= "abandoned" then return end

    SendTransfer(sessionId, channel)
    self:SendSyncDigest(channel)
end

-- ============================================================================
-- Public: broadcast digest of all own sessions
-- ============================================================================

function addon:SendSyncDigest(channel)
    channel = channel or self:GetGroupChannel()
    if not channel then return end

    local ids = BuildOwnedSessionIds()
    if #ids == 0 then return end

    EnqueueMessage("WRSYNC_DIGEST", table.concat(ids, ","), channel)
    addon:Debug(string.format("[Sync] Digest (%d Sessions) auf %s in Queue", #ids, channel))
end

-- ============================================================================
-- GROUP_ROSTER_UPDATE handler (debounced)
-- ============================================================================

local digestDebounceTimer = nil

function addon:OnGroupRosterUpdate()
    if not WhateverRoyaleDB or not WhateverRoyaleDB.settings then return end
    if not WhateverRoyaleDB.settings.autoShareSessions then return end

    if digestDebounceTimer then
        digestDebounceTimer:Cancel()
        digestDebounceTimer = nil
    end

    digestDebounceTimer = C_Timer.After(DIGEST_DEBOUNCE, function()
        digestDebounceTimer = nil
        local channel = addon:GetGroupChannel()
        if channel then
            addon:SendSyncDigest(channel)
        end
    end)
end

-- ============================================================================
-- Inbound reassembly buffers
-- ============================================================================

local inFlight = {}  -- key = sender.."|"..tId → {sessionId, totalChunks, chunks, receivedAt}

local function CleanupTimedOut()
    local now = GetTime()
    for key, transfer in pairs(inFlight) do
        if now - transfer.receivedAt > TRANSFER_TIMEOUT then
            addon:Debug("[Sync] Transfer Timeout: " .. key)
            inFlight[key] = nil
        end
    end
end

-- ============================================================================
-- Post-merge stats rebuild (debounced 1 s to batch rapid inserts)
-- ============================================================================

local rebuildPending = false

local function ScheduleRebuild()
    if rebuildPending then return end
    rebuildPending = true
    C_Timer.After(1, function()
        rebuildPending = false
        addon:RebuildAllCharacterStats()
        addon:Debug("[Sync] Charakter-Stats nach Sync neu berechnet")
    end)
end

-- ============================================================================
-- Merge incoming payload into local DB
-- ============================================================================

function addon:MergeSyncPayload(payload, sender)
    if payload.format ~= "WhateverRoyale-Export" then
        addon:Debug("[Sync] Unbekanntes Payload-Format: " .. tostring(payload.format))
        return
    end

    local localSchema = (WhateverRoyaleDB and WhateverRoyaleDB.schemaVersion) or 3
    if payload.schemaVersion and payload.schemaVersion > localSchema then
        addon:Debug("[Sync] Payload von neuerer Schema-Version " ..
            payload.schemaVersion .. ", wird uebersprungen")
        return
    end

    local senderNorm = NormalizeSender(sender)
    local inserted   = 0

    -- Merge sessions
    for _, session in ipairs(payload.sessions or {}) do
        if session.sessionId and
           (session.status == "completed" or session.status == "abandoned") and
           session.hostCharacter == senderNorm then

            if not WhateverRoyaleDB.sessions[session.sessionId] then
                WhateverRoyaleDB.sessions[session.sessionId] = session
                inserted = inserted + 1
                addon:Debug("[Sync] Session " .. session.sessionId .. " von " .. sender .. " uebernommen")
            else
                addon:Debug("[Sync] Session " .. session.sessionId .. " bereits vorhanden, uebersprungen")
            end
        else
            addon:Debug(string.format("[Sync] Session abgelehnt (Absender=%s Host=%s Status=%s)",
                senderNorm, tostring(session.hostCharacter), tostring(session.status)))
        end
    end

    -- Create slim character records for unknown participants (name resolution only).
    -- Never overwrite existing local linkage or stats.
    for _, charData in ipairs(payload.characters or {}) do
        if charData.characterId and not WhateverRoyaleDB.characters[charData.characterId] then
            local name, realm = strsplit("-", charData.characterId)
            WhateverRoyaleDB.characters[charData.characterId] = {
                characterId    = charData.characterId,
                name           = name or charData.characterId,
                realm          = realm or "",
                characterType  = "unlinked",
                mainCharacter  = nil,
                firstSeen      = time(),
                lastSeen       = time(),
                stats = {
                    overall        = self:CreateEmptyStats(),
                    byGame         = {},
                    sessionHistory = {},
                },
            }
        end
    end

    if inserted > 0 then
        local displayName = strsplit("-", senderNorm)
        addon:Success(string.format("[Sync] %d neue Session(s) von %s importiert",
            inserted, displayName))
        ScheduleRebuild()
    end
end

-- ============================================================================
-- Main incoming message router (called from Communication.lua)
-- ============================================================================

function addon:HandleSyncMessage(msgType, data, channel, sender)
    local mySelf = self:GetCurrentCharacterId()

    -- Ignore own messages (we receive our own RAID/PARTY broadcasts)
    if NormalizeSender(sender) == mySelf then return end

    if not WhateverRoyaleDB then return end

    CleanupTimedOut()

    -- ── WRSYNC_DIGEST ────────────────────────────────────────────────────────
    if msgType == "WRSYNC_DIGEST" then
        if not WhateverRoyaleDB.settings.autoShareSessions then return end
        local ch = self:GetGroupChannel()
        if not ch then return end

        for sid in data:gmatch("[^,]+") do
            if sid ~= "" and not WhateverRoyaleDB.sessions[sid] then
                EnqueueMessage("WRSYNC_REQ", sid, ch)
                addon:Debug("[Sync] Fordere Session " .. sid .. " von " .. sender .. " an")
            end
        end

    -- ── WRSYNC_REQ ───────────────────────────────────────────────────────────
    elseif msgType == "WRSYNC_REQ" then
        if not WhateverRoyaleDB.settings.autoShareSessions then return end
        local sessionId = data
        local session = WhateverRoyaleDB.sessions[sessionId]
        if not session then return end
        -- Only respond if we are the host of this session
        if session.hostCharacter ~= mySelf then return end
        if session.status ~= "completed" and session.status ~= "abandoned" then return end
        local ch = self:GetGroupChannel()
        if not ch then return end
        SendTransfer(sessionId, ch)

    -- ── WRSYNC_BEGIN ─────────────────────────────────────────────────────────
    elseif msgType == "WRSYNC_BEGIN" then
        local tId, sessionId, totalChunksStr, protoStr = strsplit("|", data)
        local proto       = tonumber(protoStr) or 1
        local totalChunks = tonumber(totalChunksStr)
        if proto > SYNC_PROTO then
            addon:Debug("[Sync] Unbekannte Protokoll-Version " .. proto .. ", uebersprungen")
            return
        end
        if not totalChunks or totalChunks <= 0 or totalChunks > MAX_CHUNKS then return end

        local key = sender .. "|" .. tId
        inFlight[key] = {
            sessionId   = sessionId,
            sender      = sender,
            totalChunks = totalChunks,
            chunks      = {},
            receivedAt  = GetTime(),
        }
        addon:Debug(string.format("[Sync] BEGIN Transfer %s von %s (%d Chunks)",
            tId, sender, totalChunks))

    -- ── WRSYNC_DATA ──────────────────────────────────────────────────────────
    elseif msgType == "WRSYNC_DATA" then
        -- limit=3 so chunk can safely contain "|" characters
        local tId, indexStr, chunk = strsplit("|", data, 3)
        local key = sender .. "|" .. tId
        local transfer = inFlight[key]
        if not transfer then return end
        local idx = tonumber(indexStr)
        if not idx then return end
        transfer.chunks[idx] = chunk
        transfer.receivedAt  = GetTime()  -- reset timeout

    -- ── WRSYNC_END ───────────────────────────────────────────────────────────
    elseif msgType == "WRSYNC_END" then
        local tId = data
        local key = sender .. "|" .. tId
        local transfer = inFlight[key]
        if not transfer then return end
        inFlight[key] = nil

        -- Verify all chunks arrived
        for i = 1, transfer.totalChunks do
            if not transfer.chunks[i] then
                addon:Debug("[Sync] Unvollstaendiger Transfer " .. tId .. " von " .. sender)
                return
            end
        end

        -- Reassemble and decode
        local encoded = table.concat(transfer.chunks)
        local payload = SyncDecode(encoded)
        if not payload then
            addon:Debug("[Sync] Dekodierung fehlgeschlagen fuer Transfer " .. tId)
            return
        end

        addon:Debug(string.format("[Sync] END Transfer %s von %s — verarbeite Payload", tId, sender))
        self:MergeSyncPayload(payload, sender)
    end
end
